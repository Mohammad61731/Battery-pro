package com.batterypro

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class PV(
    val bg: Brush, val border: Color?, val bw: Float, val accent: Color,
    val text: Color, val muted: Color, val track: Color, val bar: Color
)

private fun previewLook(look: String, base: Color): PV {
    val dark = Color(0xFF0B0F14)
    return when (look) {
        "gradient" -> PV(
            Brush.linearGradient(listOf(lerp(base, Color.Black, 0.25f), lerp(base, Color.Black, 0.65f))), null, 0f,
            Color.White, Color.White, Color(0xFFE5E7EB), Color(0x44FFFFFF), Color.White
        )
        "neon" -> PV(Brush.linearGradient(listOf(Color.Black, Color.Black)), base, 1.5f, base, Color.White, Color(0xFF9AA4B2), Color(0x33FFFFFF), base)
        "classic" -> PV(Brush.linearGradient(listOf(Color(0xFF22262C), Color(0xFF22262C))), null, 0f, base, Color(0xFFF3F4F6), Color(0xFF9CA3AF), Color(0x33FFFFFF), base)
        "paper" -> PV(
            Brush.linearGradient(listOf(Color(0xFFF4F5F7), Color(0xFFF4F5F7))), Color(0xFFD1D5DB), 1f,
            lerp(base, Color.Black, 0.3f), Color(0xFF111827), Color(0xFF6B7280), Color(0x22000000), lerp(base, Color.Black, 0.15f)
        )
        else -> PV(
            Brush.linearGradient(listOf(lerp(base, dark, 0.86f), lerp(base, dark, 0.95f))), lerp(base, dark, 0.62f), 1f,
            base, Color.White, Color(0xFF9AA4B2), Color(0x33FFFFFF), base
        )
    }
}

@Composable
private fun PBar(frac: Float, h: Int, pv: PV) {
    Box(Modifier.fillMaxWidth().height(h.dp).clip(RoundedCornerShape((h / 2).dp)).background(pv.track)) {
        Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(RoundedCornerShape((h / 2).dp)).background(pv.bar))
    }
}

@Composable
private fun Frame(pv: PV, corner: Int, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(corner.dp)
    var m = Modifier.fillMaxWidth().clip(shape).background(pv.bg)
    if (pv.border != null) m = m.border(pv.bw.dp, pv.border, shape)
    Column(m, content = content)
}

@Composable
private fun PvCompact(pv: PV, s: Float, padC: Int, corner: Int) {
    Frame(pv, corner) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = padC.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⚡ ۱۳۶۵ mA", Modifier.weight(1f), color = pv.accent, fontSize = (18 * s).sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("۷۷٪", color = pv.accent, fontSize = (16 * s).sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(2.dp))
            PBar(0.77f, 4, pv)
            Spacer(Modifier.height(2.dp))
            Text("۴.۲۱ V  •  ۵.۷ W  •  ۳۴.۰ °C", color = pv.muted, fontSize = (11 * s).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PvCard(pv: PV, s: Float, padB: Int, corner: Int) {
    Frame(pv, corner) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = padB.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⚡ در حال شارژ", Modifier.weight(1f), color = pv.accent, fontSize = (14 * s).sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("۷۷٪", color = pv.accent, fontSize = (18 * s).sp, fontWeight = FontWeight.Bold)
            }
            Text("۱۳۶۵ mA", color = pv.accent, fontSize = (28 * s).sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            PBar(0.77f, 7, pv)
            Text("⏱ تا پر شدن ≈ ۴۵ دقیقه", Modifier.padding(top = 6.dp), color = pv.text, fontSize = (12 * s).sp, maxLines = 1)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                listOf("ولتاژ" to "۴.۲۱ V", "توان" to "۵.۷ W", "دما" to "۳۴ °C", "سلامت" to "سالم").forEach { (l, v) ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(l, color = pv.muted, fontSize = (10 * s).sp, maxLines = 1)
                        Text(v, color = pv.text, fontSize = (13 * s).sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun PvGraphic(pv: PV, s: Float, padB: Int, corner: Int) {
    Frame(pv, corner) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = padB.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(76.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = size.minDimension * 0.13f
                    val d = size.minDimension - sw
                    val tl = Offset(sw / 2f, sw / 2f)
                    drawArc(pv.track, 135f, 270f, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                    drawArc(pv.bar, 135f, 270f * 0.77f, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                }
                Text("۷۷٪", color = pv.text, fontSize = (16 * s).sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("⚡ در حال شارژ", color = pv.accent, fontSize = (12 * s).sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("۱۳۶۵ mA", color = pv.text, fontSize = (22 * s).sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Box(Modifier.fillMaxWidth().height(24.dp).padding(vertical = 3.dp).clip(RoundedCornerShape(4.dp)).background(pv.track))
                Text("۴.۲۱ V  •  ۵.۷ W  •  ۳۴ °C", color = pv.muted, fontSize = (11 * s).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun PvSystem() {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text("۱۳۶۵ mA • ۷۷٪", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("ولتاژ ۴.۲۱ V • توان ۵.۷ W • دما ۳۴ °C", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Spacer(Modifier.height(2.dp))
        Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.background)) {
            Box(Modifier.fillMaxWidth(0.77f).fillMaxHeight().background(Themes.cur.charge))
        }
    }
}

/** پیش‌نمایش زنده‌ی اعلان؛ با هر تغییر تنظیمات (ver) دوباره ساخته میشه */
@Composable
fun NotifPreviewLive(ver: Int) {
    val ctx = LocalContext.current
    val tpl = remember(ver) { Prefs.s(ctx, "n_template", "card") }
    val look = remember(ver) { Prefs.s(ctx, "n_look", "modern") }
    val s = remember(ver) { Prefs.i(ctx, "n_text", 100) / 100f }
    val padC = remember(ver) { Prefs.i(ctx, "n_pad_c", 3) }
    val padB = remember(ver) { Prefs.i(ctx, "n_pad_b", 12) }
    val corner = remember(ver) { Prefs.i(ctx, "n_corner", 20) }
    val compat = remember(ver) { Prefs.b(ctx, "n_compat", NotifStyles.defaultCompat()) }
    val pv = previewLook(look, Themes.cur.charge)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (tpl == "system") {
            Text("پیش‌نمایش", fontSize = 11.sp, color = Muted)
            PvSystem()
        } else {
            Text("حالت بسته (پرده‌ی اعلان / صفحه‌ی قفل)", fontSize = 11.sp, color = Muted)
            PvCompact(pv, s, padC, corner)
            Text(if (compat && tpl != "compact") "حالت باز (سازگار: همان ارتفاع جمع‌وجور)" else "حالت باز", fontSize = 11.sp, color = Muted)
            when {
                tpl == "compact" || compat -> PvCompact(pv, s, padC, corner)
                tpl == "graphic" -> PvGraphic(pv, s, padB, corner)
                else -> PvCard(pv, s, padB, corner)
            }
        }
    }
}
