package com.batterypro

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun KV(label: String, value: String, color: Color = Color.Unspecified) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Muted, fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = color)
    }
}

@Composable
fun ExpandCard(title: String, body: String) {
    var open by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { open = !open }.padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(if (open) "▲" else "▼", color = Muted, fontSize = 12.sp)
        }
        if (open) Text(body, Modifier.padding(top = 8.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private const val TEST_SEC = 45

@Composable
fun ChargerScreen() {
    val ctx = LocalContext.current
    var i by remember { mutableStateOf(BatteryReader.read(ctx)) }
    var running by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var report by remember { mutableStateOf<Report?>(null) }
    var msg by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var saved by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            i = BatteryReader.read(ctx)
            delay(1000)
        }
    }

    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        val st = System.currentTimeMillis()
        msg = ""
        report = null
        progress = 0f
        var last = BatteryReader.read(ctx)
        while (true) {
            val now = System.currentTimeMillis()
            val el = (now - st) / 1000f
            progress = (el / TEST_SEC).coerceAtMost(1f)
            last = BatteryReader.read(ctx)
            if (!last.plugged) {
                msg = "⚠️ شارژر وسط تست جدا شد؛ دوباره امتحان کن."
                running = false
                return@LaunchedEffect
            }
            if (el >= TEST_SEC) break
            delay(1000)
        }
        // نمونه‌های ۷ ثانیه‌ی اول بعد از وصل شارژر (ناپایدار) حذف میشن
        val from = maxOf(st, BatteryReader.plugSince() + 7000L)
        val samples = BatteryReader.chargeSamples().filter { it.t >= from }
        val r = ChargerAnalyzer.analyze(samples, last, Prefs.i(ctx, "factory_w", 25))
        if (r == null) msg = "نمونه‌ی کافی جمع نشد؛ دوباره امتحان کن." else report = r
        running = false
    }

    val surface = MaterialTheme.colorScheme.surface
    val direct = remember(i.plugged, i.voltageMv) { Sysfs.direct(i.plugged) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("تست و تحلیل شارژر", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Section("اتصال فعلی", Help.CHG_CONN) {
            if (!i.plugged) {
                Text("🔌 الان به شارژر وصل نیستی. شارژر رو وصل کن تا اطلاعاتش اینجا بیاد.", color = Orange)
            } else {
                if (i.settling) Text("⏳ چند ثانیه‌ی اول اتصاله؛ عددها هنوز در حال جا افتادنه…", color = Orange, fontSize = 13.sp)
                KV("نوع اتصال", plugName(i.plugType))
                KV("ولتاژ باتری (لحظه‌ای)", String.format(Locale.US, "%.2f V", i.voltageMv / 1000f).fa())
                KV("جریان ورودی به باتری", "${i.currentMa} mA".fa())
                KV("توان رسیده به باتری", String.format(Locale.US, "%.1f W", i.powerW).fa())
                KV("دمای باتری", String.format(Locale.US, "%.1f °C", i.tempC).fa())
                if (direct.vbusMv > 0) {
                    KV("ولتاژ ورودی شارژر (مستقیم)", String.format(Locale.US, "%.2f V", direct.vbusMv / 1000f).fa(), Green)
                }
                if (direct.protocol.isNotEmpty()) KV("پروتکل شارژر", direct.protocol, Green)
                if (direct.chargeType.isNotEmpty()) KV("نوع شارژ (سیستم)", direct.chargeType)
                if (i.maxChgMv > 0) KV("حداکثر ولتاژ اعلامی شارژر", String.format(Locale.US, "%.1f V", i.maxChgMv / 1000f).fa())
                if (i.maxChgMa > 0) KV("حداکثر جریان اعلامی شارژر", "${i.maxChgMa} mA".fa())
                if (direct.vbusMv == 0 && i.maxChgMv == 0) {
                    Text("ℹ️ این گوشی ولتاژ ورودی شارژر رو به برنامه‌ها نمیده؛ رده‌ی ولتاژ از روی توان تخمین زده میشه.", fontSize = 12.sp, color = Muted)
                }
            }
        }

        Section("مشخصات گوشی (برای مقایسه با شارژر فابریک)", Help.CHG_FACTORY) {
            StepRow("توان شارژر فابریک گوشی", "factory_w", 25, 5, 240, 5, "وات")
            StepRow("ظرفیت باتری روی جعبه (۰ = نامشخص)", "design_mah", 0, 0, 12000, 100, "mAh", Help.CAP)
            SwitchRow("تحلیل خودکار بعد از وصل شارژر", "chg_auto", true, "بعد از ≈ ۲۰ ثانیه یک اعلان توضیحی میاد", Help.CHG_LIVE)
        }

        Section("تست ${TEST_SEC} ثانیه‌ای", Help.CHG_TEST) {
            Text(
                "شارژر رو وصل کن، صفحه رو خاموش یا بی‌حرکت بذار و بازی/فیلم رو ببند. ترجیحاً باتری بین ۱۰ تا ۷۰٪ باشه (بعد از ۸۰٪ شارژ خودکار کند میشه).",
                fontSize = 13.sp, color = Muted
            )
            if (i.percent >= 85 && i.plugged) Text("⚠️ باتری بالای ۸۵٪ه؛ نتیجه دقیق نخواهد بود.", color = Orange, fontSize = 13.sp)
            if (running) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(5.dp)))
                Text("در حال سنجش… ${(progress * TEST_SEC).toInt()} / $TEST_SEC ثانیه".fa(), fontSize = 13.sp)
                OutlinedButton(onClick = { running = false }) { Text("لغو") }
            } else {
                Button(onClick = { running = true }, enabled = i.plugged) { Text("شروع تست") }
            }
            if (msg.isNotEmpty()) Text(msg, color = Orange, fontSize = 13.sp)
        }

        val r = report
        if (r != null) {
            val lc = if (r.level == 0) Green else if (r.level == 1) Orange else Red
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("نتیجه‌ی تست", color = Green, fontWeight = FontWeight.Bold)
                    Text("${r.tierLabel} ≈ ${r.watt()} وات".fa(), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = lc)
                    Text("${r.verdict} • ${ChargerAnalyzer.levelText(r.level)} • امتیاز ${r.score}".fa(), color = lc, fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(
                        progress = { r.score / 100f }, color = lc,
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(5.dp))
                    )
                    KV("رده‌ی ولتاژ شارژر" + if (r.voltMeasured) " (اندازه‌گیری)" else " (تخمین)", r.voltClass.fa())
                    KV("میانگین / اوج توان", String.format(Locale.US, "%.1f / %.1f W", r.avgW, r.peakW).fa())
                    KV("میانگین جریان", "${r.avgMa} mA".fa())
                    KV("میانگین ولتاژ باتری", String.format(Locale.US, "%.2f V", r.avgMv / 1000f).fa())
                    KV("بیشترین ولتاژ باتری", String.format(Locale.US, "%.2f V", r.maxMv / 1000f).fa())
                    KV("تغییر دما", String.format(Locale.US, "%.1f → %.1f °C", r.tempStart, r.tempEnd).fa())
                    KV("پایداری جریان", "${r.stability}٪ (${r.dips} افت)".fa())
                    KV("نسبت به فابریک", "${r.factoryRatio}٪".fa())
                    Spacer(Modifier.height(4.dp))
                    r.lines.forEach { Text(it.fa(), fontSize = 13.sp) }
                    Text("⚠️ این تحلیل از رفتار باتری استنباط میشه؛ جایگزین دستگاه تستر USB نیست.", fontSize = 11.sp, color = Muted)
                    OutlinedTextField(
                        value = name, onValueChange = { name = it }, singleLine = true,
                        label = { Text("اسم شارژر (مثلاً: شارژر اصلی، شارژر ماشین)") }, modifier = Modifier.fillMaxWidth()
                    )
                    Button(onClick = {
                        ChargerStore.add(ctx, name, r)
                        name = ""
                        saved++
                    }) { Text("ذخیره برای مقایسه") }
                }
            }
        }

        val rows = remember(saved) { ChargerStore.all(ctx) }
        if (rows.isNotEmpty()) {
            Section("مقایسه‌ی شارژرهای تست‌شده", Help.CHG_COMPARE) {
                rows.sortedByDescending { it.score }.forEach { w ->
                    val c = if (w.level == 0) Green else if (w.level == 1) Orange else Red
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(w.name, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                            Text("امتیاز ${w.score}".fa(), color = c, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            String.format(Locale.US, "%.1f W • %.2f V • %+.1f°C • پایداری %d%%", w.avgW, w.avgMv / 1000f, w.rise, w.stab).fa(),
                            fontSize = 12.sp, color = Muted
                        )
                    }
                }
                OutlinedButton(onClick = { ChargerStore.clear(ctx); saved++ }) { Text("پاک کردن لیست") }
            }
        }

        Section("راهنمای انواع شارژر") {
            ExpandCard("شارژر معمولی ۵ ولت (۵ تا ۱۰ وات)", Help.G_BASIC)
            ExpandCard("شارژ سریع QC و PD (۹ تا ۲۰ ولت)", Help.G_FAST)
            ExpandCard("شارژرهای اختصاصی (VOOC، Mi Turbo و...)", Help.G_PROP)
            ExpandCard("شارژ بی‌سیم", Help.G_WIRELESS)
            ExpandCard("ولتاژ بالا یا پایین به باتری آسیب میزنه؟", Help.G_VOLT)
            ExpandCard("نشانه‌های شارژر یا کابل بد", Help.G_BAD)
        }
        Spacer(Modifier.height(16.dp))
    }
}
