package com.batterypro

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews

class BatteryWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        push(c, m, ids, BatteryReader.read(c))
    }

    companion object {
        fun refresh(c: Context, i: BatteryInfo) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, BatteryWidget::class.java))
            if (ids.isNotEmpty()) push(c, m, ids, i)
        }

        private fun push(c: Context, m: AppWidgetManager, ids: IntArray, i: BatteryInfo) {
            val rv = RemoteViews(c.packageName, R.layout.widget_battery)
            rv.setTextViewText(R.id.w_status, if (i.plugged) "⚡ در حال شارژ" else "🔋 در حال مصرف")
            rv.setTextViewText(R.id.w_main, "${i.currentMa} mA".fa())
            rv.setTextViewText(R.id.w_sub, "${i.percent}٪ • ${Fmt.long(i, "temp")}".fa())
            rv.setOnClickPendingIntent(R.id.w_main, Notif.openApp(c))
            m.updateAppWidget(ids, rv)
        }
    }
}
