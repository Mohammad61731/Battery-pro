package com.batterypro

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

val Green: Color get() = Themes.cur.charge
val Blue: Color get() = Themes.cur.discharge
val Orange = Color(0xFFFB923C)
val Red = Color(0xFFF87171)
val Muted: Color get() = Themes.cur.muted

object Help {
    const val CURRENT = "جریان یعنی مقدار انرژی که در هر لحظه وارد باتری میشه (موقع شارژ) یا ازش خارج میشه (موقع مصرف)، با واحد میلی‌آمپر (mA). هرچی عدد بزرگ‌تر باشه شارژ سریع‌تره، یا مصرف گوشی در اون لحظه بیشتره. ۱۰۰۰ mA برابر ۱ آمپره. بعضی گوشی‌ها این عدد رو دقیق نمیدن؛ اینجا همیشه مثبت نشون داده میشه."
    const val POWER = "توان (وات) = ولتاژ × جریان. مثلاً ۴ ولت × ۵ آمپر = ۲۰ وات. نشون میده شارژر در هر ثانیه چقدر انرژی به گوشی میرسونه و مقایسه‌ی بهتری از سرعت شارژ نسبت به فقط آمپره."
    const val VOLT = "ولتاژ باتری لیتیومی بین حدود ۳.۳ ولت (تقریباً خالی) تا ۴.۴ ولت (پر) تغییر می‌کنه و موقع شارژ کمی بالاتر از حالت عادیه."
    const val TEMP = "دمای مناسب باتری ۲۰ تا ۳۵ درجه‌ست. بالای ۴۰ درجه سرعت شارژ خودکار کم میشه و عمر باتری آسیب می‌بینه. موقع شارژ، کاور و بازی سنگین رو کنار بذار."
    const val HEALTH = "وضعیتی که خود اندروید برای سلامت باتری گزارش میده (سالم، داغ شده، خراب و...). درصد دقیق فرسودگی در دسترس برنامه‌ها نیست."
    const val TECH = "نوع شیمی باتری؛ تقریباً همیشه Li-ion یا Li-poly."
    const val CAP = "ظرفیت تخمینی از شمارنده‌ی شارژ باتری و درصد فعلی حساب میشه (شمارنده ÷ درصد). تقریبیه و هرچی درصد بیشتر باشه دقیق‌تره. ممکنه با ظرفیت روی جعبه فرق کنه. بعضی گوشی‌ها این شمارنده رو نمیدن و اینجا خط تیره میاد."
    const val ETA = "زمان تقریبی از ظرفیت باتری، درصد فعلی، جریان لحظه‌ای (میانگین‌گیری‌شده) و دما حساب میشه. تا ۸۰٪ شارژ با جریان ثابت پیش میره، از ۸۰٪ تا ۱۰۰٪ جریان کم میشه (شارژ مرحله‌ای) و اگه دما بالای ۳۸ درجه باشه کندتر شدن شارژ هم لحاظ میشه. موقع مصرف، زمان تا خالی شدن با همین مصرف فعلی تخمین زده میشه و با تغییر مصرف عوض میشه."
    const val SESSION = "آمار از لحظه‌ای که شارژر وصل شده: درصد اضافه‌شده، مدت زمان و میانگین سرعت شارژ (درصد در ساعت)."
    const val OPT = "امتیاز بهینگی از روی تنظیمات گوشی (روشنایی، زمان خاموشی صفحه، حالت صرفه‌جویی، موقعیت مکانی)، دمای باتری و برنامه‌های پرمصرف امروز حساب میشه. اندروید اجازه نمیده یه برنامه، برنامه‌ی دیگه رو ببنده؛ برای همین کنار هر مشکل دکمه‌ای هست که تو صفحه‌ی مربوطه خودت درستش کنی."
    const val TOOLS = "تایمر و کرنومتر روی جزیره‌ی بالای صفحه نشون داده میشن. به دسترسی «نمایش روی برنامه‌های دیگر» نیاز دارن. پایان تایمر با اعلان هم خبر داده میشه، حتی اگه صفحه خاموش باشه."
    const val CHART = "نمودار از داده‌هایی که برنامه هر ۱ دقیقه ثبت می‌کنه کشیده میشه. برای دیدن نمودار، «ثبت تاریخچه» باید روشن باشه و چند دقیقه از اجرای برنامه گذشته باشه."
    const val APPS = "«شخصی» برنامه‌هایی که خودت نصب کردی و «رسمی» برنامه‌های سیستمی گوشیه. زمان‌ها از آمار استفاده‌ی خود اندروید میاد؛ مصرف دقیق باتری هر برنامه برای برنامه‌ها قابل دسترسی نیست."
    const val S_GENERAL = "اگه «فعال بودن برنامه» رو خاموش کنی هیچ‌چیز در پس‌زمینه اجرا نمیشه و مصرفش صفره. تنظیمات بعد از خاموش و روشن شدن گوشی هم می‌مونن."
    const val S_INTERVAL = "هر چند ثانیه یک بار اطلاعات تازه خونده میشه (فقط وقتی صفحه روشنه). عدد بزرگ‌تر = مصرف باتری کمتر."
    const val S_ECO = "وقتی باتری زیر ۲۰٪ و بدون شارژ باشه، فاصله‌ی به‌روزرسانی ۳ برابر میشه تا خود برنامه تقریباً هیچ باتری مصرف نکنه."
    const val S_HIST = "هر ۱ دقیقه یک نمونه (درصد، جریان، ولتاژ، دما) برای نمودار ذخیره میشه. فقط ۲۴ ساعت آخر نگه داشته میشه و حجمش خیلی کمه."
    const val S_ICON = "اندروید اجازه نمیده متن دلخواه دقیقاً کنار ساعت نوشته بشه؛ به‌جاش عدد زنده داخل آیکن نوار وضعیت نشون داده میشه. بالاش مقدار و پایینش واحد یا اطلاعات دلخواهه. بیشتر از ۴ رقم جا نمیشه."
    const val S_ICON_SUB = "خط پایین آیکن نوار وضعیت: واحد (مثل mA)، ولتاژ، دما، درصد یا هیچی."
    const val S_NOTIF = "اعلان باتری در پرده‌ی اعلان. چهار قالب داره (ساده، فشرده، کارت، گرافیکی) و پنج طرح (مدرن، گرادیانت، نئون، کلاسیک تیره و روشن). ارتفاع، اندازه‌ی متن و گردی گوشه‌ها قابل تنظیمه و رنگ‌ها از تم برنامه میاد. جای اعلان ثابته و با اعلان‌های دیگه (مثل فیلترشکن) بالا پایین نمیشه."
    const val S_ISLAND = "قرصی بالای صفحه که با انیمیشن باز میشه. نیازمند دسترسی «نمایش روی برنامه‌های دیگر» و در شیائومی/هایپراواس چند مجوز دیگه‌ست (پایین همین بخش دکمه‌هاش هست)."
    const val S_MIUI = "در شیائومی (MIUI / HyperOS) باید «نمایش پنجره‌های بازشو هنگام اجرا در پس‌زمینه» رو در مجوزهای برنامه روی «مجاز» بذاری و «شروع خودکار» رو هم فعال کنی. وگرنه جزیره وقتی برنامه بسته‌ست دیده نمیشه."
    const val S_MUSIC = "نام آهنگ در حال پخش (از هر پخش‌کننده‌ای) روی جزیره میاد. لازمه «دسترسی به اعلان‌ها» رو به برنامه بدی؛ فقط وضعیت پخش خونده میشه و هیچ اعلانی ذخیره نمیشه."
    const val S_ALERT = "هشدارها وقتی اتفاقی بیفته اعلان میدن: شارژ کامل، دمای بالا، رسیدن به حد شارژ، برنامه‌ی پرمصرف."
    const val S_LIMIT = "باتری لیتیومی اگه بین ۲۰٪ تا ۸۰٪ نگه داشته بشه بیشتر عمر می‌کنه. این گزینه فقط هشدار میده؛ قطع شارژ بدون دسترسی روت ممکن نیست."
    const val CYCLES = "تعداد دفعاتی که باتری معادل یک شارژ کامل (۰ تا ۱۰۰٪) مصرف کرده. فقط اندروید ۱۴ به بالا و فقط بعضی گوشی‌ها این عدد رو به برنامه‌ها میدن؛ اگه خط تیره دیدی یعنی گوشیت نمیده. معمولاً بعد از ۵۰۰ تا ۱۰۰۰ سیکل ظرفیت باتری محسوس کم میشه."
    const val CHG_LIVE = "تحلیل از رفتار باتری موقع شارژ ساخته میشه: توان (وات)، ثبات جریان، بیشترین ولتاژ و افزایش دما. چند ثانیه‌ی اول بعد از وصل شارژر عددها پرش دارن و شمرده نمیشن؛ تحلیل بعد از جا افتادن عددها انجام میشه. اندروید ولتاژ خروجی خود شارژر رو به برنامه‌ها نمیده، پس اگه گوشیت اجازه نده، رده‌ی ولتاژ تخمینیه."
    const val CHG_CONN = "اطلاعات اتصال فعلی. «ولتاژ ورودی شارژر» و «پروتکل» فقط روی گوشی‌هایی که این اطلاعات رو از سیستم میدن اندازه‌گیری میشه؛ بقیه‌ی عددها ولتاژ و جریان خود باتری‌ان."
    const val CHG_FACTORY = "توان شارژر اصلی گوشی (روی آداپتور یا جعبه نوشته، مثلاً ۲۵ یا ۳۳ یا ۶۷ وات). برنامه سرعت شارژر فعلی رو با این عدد مقایسه می‌کنه تا بگه فابریک‌ه یا ضعیف‌تر/قوی‌تره. ظرفیت روی جعبه هم برای محاسبه‌ی «سلامت تخمینی» باتری لازمه."
    const val CHG_TEST = "تست ۴۵ ثانیه‌ای هر ثانیه یک بار ولتاژ، جریان و دما رو می‌خونه، ۷ ثانیه‌ی اول اتصال و ۶ ثانیه‌ی اول تست رو که ناپایداره حذف می‌کنه و بعد توان، ثبات جریان، بیشترین ولتاژ و گرم شدن رو بررسی می‌کنه. هرچی گوشی بی‌حرکت‌تر و صفحه خاموش‌تر باشه نتیجه دقیق‌تره."
    const val CHG_COMPARE = "نتیجه‌ی تست شارژرها رو با اسم ذخیره کن تا بعداً بتونی بین شارژرها و کابل‌های مختلف مقایسه کنی. فقط ۲۰ نتیجه‌ی آخر نگه داشته میشه."
    const val G_BASIC = "شارژرهای قدیمی و ساده ۵ ولت هستن: ۵ ولت × ۱ آمپر = ۵ وات، ۵ ولت × ۲ آمپر = ۱۰ وات. پورت USB کامپیوتر معمولاً فقط ۲.۵ تا ۴.۵ وات میده. این شارژرها امن‌ان ولی کندن؛ گوشی‌های جدید باهاشون چند ساعت طول میکشه."
    const val G_FAST = "QC (کوالکام) و PD (استاندارد USB-C) ولتاژ رو بین ۵، ۹، ۱۲، ۱۵ و ۲۰ ولت عوض می‌کنن. نکته‌ی مهم اینه که گوشی و شارژر قبل از بالا بردن ولتاژ با هم «مذاکره» می‌کنن و گوشی ولتاژ مورد نیازش رو می‌خواد؛ پس شارژر قوی‌تر خطری نداره. PPS هم ولتاژ و جریان رو ریز و دقیق تنظیم می‌کنه (سامسونگ ۲۵/۴۵ وات، پیکسل)."
    const val G_PROP = "برندها پروتکل مخصوص خودشون دارن: VOOC/SuperVOOC (اوپو، وان‌پلاس، ریلمی)، Mi Turbo/HyperCharge (شیائومی)، Warp، FCP/SCP (هواوی). این‌ها فقط با شارژر و معمولاً کابل مخصوص خودشون به سرعت کامل میرسن؛ با شارژر دیگه معمولاً به ۱۰ تا ۲۰ وات برمی‌گردن و این عیب نیست."
    const val G_WIRELESS = "شارژ بی‌سیم (Qi) معمولاً ۵ تا ۱۵ وات (Qi2 تا ۱۵ وات) و مدل‌های اختصاصی تا ۵۰ وات و بیشتر. بازدهش کمتره و گرمای بیشتری تولید می‌کنه؛ پس کاور ضخیم و فلز بین گوشی و پد ممنوع! تراز نبودن گوشی روی پد هم سرعت رو خیلی کم می‌کنه."
    const val G_VOLT = "ولتاژ بالا به‌خودی‌خود آسیب نمیزنه: شارژر استاندارد فقط وقتی ولتاژ رو بالا می‌بره که گوشی بخواد و داخل گوشی مبدل ولتاژ رو به ولتاژ مجاز باتری (حداکثر حدود ۴.۴ ولت) می‌رسونه. خطر از شارژرهای ارزان بدون استاندارد و بدون مذاکره‌ست که ولتاژ ناپایدار یا نویزدار میدن؛ نشونه‌اش گرم شدن زیاد، نوسان جریان یا رسیدن ولتاژ باتری به بالای ۴.۵ ولته. ولتاژ پایین هم فقط شارژ رو کند می‌کنه و ایمنی رو تهدید نمی‌کنه."
    const val G_BAD = "نشانه‌ها: داغ شدن زیاد شارژر یا کابل، قطع‌وصل شدن شارژ، نوسان شدید جریان، سوت‌کشیدن زیاد، قیمت خیلی ارزان یا برندهای تقلبی، سنگینی خیلی کم آداپتور، کانکتور شل. توصیه: شارژر و کابل رو از برند معتبر بخر و برای شارژ سریع، کابل مناسب همون توان (مثلاً e-marked برای بالای ۶۰ وات) استفاده کن."
    const val S_TPL = "ساده (سیستمی): اعلان معمولی اندروید، هیچ‌وقت بریده نمیشه. فشرده: یک نوار کم‌ارتفاع. کارت: کارت بزرگ با ولتاژ، توان، دما. گرافیکی: حلقه‌ی درصد و نمودار مینی."
    const val S_COMPAT = "بعضی گوشی‌ها (شیائومی/هایپراواس) اعلان رو حتی وقتی بسته‌ست با ارتفاع بزرگ می‌کشن و می‌برن. با روشن بودن این گزینه، اعلان در هر دو حالت یک نوار جمع‌وجور میشه تا هیچ‌وقت بریده نشه. روی شیائومی به‌صورت پیش‌فرض روشنه."
    const val S_SOUND = "صدای هشدار: پیش‌فرض، بی‌صدا، فقط ارتعاش، یا صدای دلخواه که خودت از لیست گوشی انتخاب می‌کنی."
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Themes.load(this)
        Notif.channels(this)
        if (Prefs.b(this, "svc_enabled", true)) BatteryService.start(this)
        setContent { App() }
    }
}

@Composable
fun App() {
    val t = Themes.cur
    val scheme = if (t.dark) darkColorScheme(
        primary = t.charge, secondary = t.discharge, onPrimary = Color.Black,
        background = t.bg, surface = t.surface, onBackground = t.text, onSurface = t.text,
        surfaceVariant = t.surfaceVar, onSurfaceVariant = t.muted
    ) else lightColorScheme(
        primary = t.charge, secondary = t.discharge, onPrimary = Color.White,
        background = t.bg, surface = t.surface, onBackground = t.text, onSurface = t.text,
        surfaceVariant = t.surfaceVar, onSurfaceVariant = t.muted
    )
    val ctx = LocalContext.current
    SideEffect {
        val w = (ctx as? ComponentActivity)?.window
        if (w != null) {
            w.statusBarColor = t.bg.toArgbInt()
            w.navigationBarColor = t.surface.toArgbInt()
            w.setBackgroundDrawable(ColorDrawable(t.bg.toArgbInt()))
            val ctl = WindowCompat.getInsetsController(w, w.decorView)
            ctl.isAppearanceLightStatusBars = !t.dark
            ctl.isAppearanceLightNavigationBars = !t.dark
        }
    }
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            var tab by remember { mutableIntStateOf(0) }
            val tabs = listOf("وضعیت" to "🔋", "شارژر" to "⚡", "نمودار" to "📈", "برنامه‌ها" to "📱", "ابزارها" to "🧰", "تنظیمات" to "⚙️")
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        tabs.forEachIndexed { idx, (tt, e) ->
                            NavigationBarItem(
                                selected = tab == idx, onClick = { tab = idx },
                                icon = { Text(e, fontSize = 20.sp) }, label = { Text(tt, fontSize = 10.sp, maxLines = 1) }
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        0 -> StatusScreen(onOpenCharger = { tab = 1 })
                        1 -> ChargerScreen()
                        2 -> ChartScreen()
                        3 -> AppsScreen()
                        4 -> ToolsScreen()
                        else -> SettingsScreen()
                    }
                }
            }
        }
    }
}

// ───────────── کامپوننت‌های کمکی ─────────────

@Composable
fun InfoIcon(title: String, text: String) {
    var open by remember { mutableStateOf(false) }
    Box(
        Modifier.padding(horizontal = 6.dp).size(20.dp).clip(CircleShape)
            .background(Color(0xFF2A3441)).clickable { open = true },
        contentAlignment = Alignment.Center
    ) { Text("!", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Orange) }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false }) { Text("باشه") } },
            title = { Text(title) },
            text = { Text(text) }
        )
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier, info: String? = null) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontSize = 12.sp, color = Muted)
                if (info != null) InfoIcon(title, info)
            }
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Section(title: String, info: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                if (info != null) InfoIcon(title, info)
            }
            content()
        }
    }
}

@Composable
fun SwitchRow(title: String, key: String, def: Boolean, sub: String? = null, info: String? = null, onChange: (Boolean) -> Unit = {}) {
    val ctx = LocalContext.current
    var v by remember { mutableStateOf(Prefs.b(ctx, key, def)) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f, fill = false))
                if (info != null) InfoIcon(title, info)
            }
            if (sub != null) Text(sub, fontSize = 12.sp, color = Muted)
        }
        Switch(checked = v, onCheckedChange = { v = it; Prefs.putB(ctx, key, it); onChange(it) })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Chips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, l) ->
            FilterChip(selected = selected == k, onClick = { onSelect(k) }, label = { Text(l) })
        }
    }
}

@Composable
fun ChoiceRow(title: String, key: String, def: String, opts: List<Pair<String, String>>, info: String? = null, refresh: Int = 0, onPick: () -> Unit = {}) {
    val ctx = LocalContext.current
    var v by remember(refresh) { mutableStateOf(Prefs.s(ctx, key, def)) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title)
            if (info != null) InfoIcon(title, info)
        }
        Chips(opts, v) { v = it; Prefs.putS(ctx, key, it); onPick() }
    }
}

@Composable
fun StepRow(title: String, key: String, def: Int, min: Int, max: Int, step: Int, unit: String, info: String? = null, onPick: () -> Unit = {}) {
    val ctx = LocalContext.current
    var v by remember { mutableIntStateOf(Prefs.i(ctx, key, def)) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f, fill = false))
            if (info != null) InfoIcon(title, info)
        }
        OutlinedButton(
            onClick = { v = (v - step).coerceAtLeast(min); Prefs.putI(ctx, key, v); onPick() },
            contentPadding = PaddingValues(0.dp), modifier = Modifier.size(36.dp)
        ) { Text("−") }
        Text("$v $unit".fa(), Modifier.padding(horizontal = 12.dp))
        OutlinedButton(
            onClick = { v = (v + step).coerceAtMost(max); Prefs.putI(ctx, key, v); onPick() },
            contentPadding = PaddingValues(0.dp), modifier = Modifier.size(36.dp)
        ) { Text("+") }
    }
}

@Composable
fun PermRow(title: String, ok: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        if (ok) Text("✅ فعال", color = Green) else Button(onClick = onClick) { Text("فعال‌سازی") }
    }
}

fun safeStart(ctx: Context, i: Intent) {
    try {
        ctx.startActivity(i)
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
        } catch (e2: Exception) { }
    }
}

fun openMiuiPerms(ctx: Context) {
    val i = Intent("miui.intent.action.APP_PERM_EDITOR")
    i.setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
    i.putExtra("extra_pkgname", ctx.packageName)
    safeStart(ctx, i)
}

fun openAutostart(ctx: Context) {
    val i = Intent()
    i.component = ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
    safeStart(ctx, i)
}

fun scoreColor(s: Int): Color = if (s >= 80) Green else if (s >= 55) Orange else Red

// ───────────── وضعیت ─────────────

fun sessionText(ctx: Context, i: BatteryInfo, nowMs: Long): String? {
    val st = Prefs.l(ctx, "sess_start_t", 0L)
    if (st == 0L) return null
    val sp = Prefs.i(ctx, "sess_start_pct", i.percent)
    val et = Prefs.l(ctx, "sess_end_t", 0L)
    val ep = Prefs.i(ctx, "sess_end_pct", i.percent)
    val endT: Long
    val endP: Int
    val title: String
    if (i.plugged) {
        endT = nowMs; endP = i.percent; title = "این نشست شارژ"
    } else if (et > 0L) {
        endT = et; endP = ep; title = "آخرین نشست شارژ"
    } else {
        return null
    }
    val min = ((endT - st) / 60000).toInt().coerceAtLeast(0)
    val gain = endP - sp
    var s = "$title: ${if (gain >= 0) "+" else ""}$gain٪ در ${Fmt.dur(min)}"
    if (min >= 3 && gain > 0) s += "\nمیانگین سرعت: ${gain * 60 / min}٪ در ساعت"
    return s.fa()
}

// ───────────── نمودار ─────────────

@Composable
fun LineChart(values: List<Float>, color: Color, modifier: Modifier) {
    val grid = Themes.cur.surfaceVar
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val mn = values.minOrNull() ?: 0f
        val mx = values.maxOrNull() ?: 1f
        val rng = if (mx - mn > 0f) mx - mn else 1f
        for (g in 0..3) {
            val y = size.height * g / 3f
            drawLine(grid, androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), strokeWidth = 2f)
        }
        val path = Path()
        val fill = Path()
        values.forEachIndexed { idx, v ->
            val x = size.width * idx / (values.size - 1)
            val y = size.height * 0.05f + size.height * 0.9f * (1f - (v - mn) / rng)
            if (idx == 0) {
                path.moveTo(x, y)
                fill.moveTo(x, size.height)
                fill.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fill.lineTo(x, y)
            }
        }
        fill.lineTo(size.width, size.height)
        fill.close()
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.30f), Color.Transparent)))
        drawPath(path, color, style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun ChartScreen() {
    val ctx = LocalContext.current
    var metric by remember { mutableStateOf("pct") }
    var hours by remember { mutableStateOf("6") }
    var pts by remember { mutableStateOf(emptyList<HistoryStore.P>()) }
    LaunchedEffect(hours) {
        while (true) {
            pts = withContext(Dispatchers.IO) { HistoryStore.read(ctx, hours.toInt()) }
            delay(30000)
        }
    }
    val vals = pts.map {
        when (metric) {
            "pct" -> it.pct.toFloat()
            "ma" -> it.ma.toFloat()
            "mv" -> it.mv / 1000f
            else -> it.temp
        }
    }
    val shown = if (vals.size > 240) vals.filterIndexed { idx, _ -> idx % (vals.size / 240 + 1) == 0 } else vals
    val (label, color) = when (metric) {
        "pct" -> "درصد باتری" to Green
        "ma" -> "جریان (mA)" to Blue
        "mv" -> "ولتاژ (V)" to Orange
        else -> "دما (°C)" to Red
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("نمودار تاریخچه", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            InfoIcon("نمودار تاریخچه", Help.CHART)
        }
        Chips(listOf("pct" to "درصد", "ma" to "جریان", "mv" to "ولتاژ", "temp" to "دما"), metric) { metric = it }
        Chips(listOf("1" to "۱ ساعت", "6" to "۶ ساعت", "24" to "۲۴ ساعت"), hours) { hours = it }
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(label, color = color, fontWeight = FontWeight.Bold)
                if (shown.size < 2) {
                    Text("هنوز داده‌ی کافی ثبت نشده؛ چند دقیقه برنامه رو باز بذار تا نمودار پر بشه.", color = Muted)
                } else {
                    LineChart(shown, color, Modifier.fillMaxWidth().height(220.dp))
                    val mn = shown.minOrNull() ?: 0f
                    val mx = shown.maxOrNull() ?: 0f
                    val avg = shown.average().toFloat()
                    Text(
                        String.format(java.util.Locale.US, "کمترین %.1f  •  بیشترین %.1f  •  میانگین %.1f", mn, mx, avg).fa(),
                        fontSize = 12.sp, color = Muted
                    )
                }
            }
        }
    }
}

// ───────────── برنامه‌ها ─────────────

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    var access by remember { mutableStateOf(UsageTracker.hasAccess(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            access = UsageTracker.hasAccess(ctx)
            delay(1000)
        }
    }
    var day by remember { mutableStateOf("0") }
    var filter by remember { mutableStateOf("all") }
    var list by remember { mutableStateOf(emptyList<UsageTracker.AppUse>()) }
    LaunchedEffect(day, access) {
        list = if (access) withContext(Dispatchers.IO) { UsageTracker.day(ctx, -day.toInt()) } else emptyList()
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("مصرف برنامه‌ها", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            InfoIcon("مصرف برنامه‌ها", Help.APPS)
        }
        if (!access) {
            Section("نیاز به دسترسی") {
                Text("برای دیدن زمان استفاده‌ی برنامه‌ها باید «دسترسی به داده‌های استفاده» رو فعال کنی.", color = Muted)
                Button(onClick = { safeStart(ctx, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) { Text("باز کردن تنظیمات") }
            }
        } else {
            Chips(
                listOf("0" to "امروز", "1" to "دیروز", "2" to "۲ روز پیش", "3" to "۳ روز پیش", "4" to "۴ روز پیش", "5" to "۵ روز پیش", "6" to "۶ روز پیش"),
                day
            ) { day = it }
            Chips(listOf("all" to "همه", "user" to "شخصی (نصب‌شده)", "sys" to "رسمی (سیستمی)"), filter) { filter = it }
            val shown = list.filter { filter == "all" || (filter == "sys") == it.system }
            val total = shown.sumOf { it.minutes }
            val maxMin = (shown.maxOfOrNull { it.minutes } ?: 1).coerceAtLeast(1)
            Text("مجموع: ${Fmt.dur(total)}".fa(), color = Muted)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown) { a ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row {
                                Text(a.label, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                                Text(Fmt.dur(a.minutes).fa(), color = if (a.minutes >= 120) Orange else Muted)
                            }
                            LinearProgressIndicator(
                                progress = { a.minutes / maxMin.toFloat() },
                                color = if (a.minutes >= 120) Orange else Green,
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}

// ───────────── ابزارها: بهینه‌ساز + تایمر/کرنومتر ─────────────

@Composable
fun ToolsScreen() {
    val ctx = LocalContext.current
    var issues by remember { mutableStateOf(emptyList<Optimizer.Issue>()) }
    var scanned by remember { mutableStateOf(false) }
    var rescan by remember { mutableIntStateOf(0) }
    LaunchedEffect(rescan) {
        val top = withContext(Dispatchers.IO) { UsageTracker.day(ctx, 0) }
        issues = Optimizer.scan(ctx, BatteryReader.read(ctx), top)
        scanned = true
    }
    val score = (100 - issues.sumOf { it.penalty }).coerceIn(0, 100)

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val te = Prefs.l(ctx, "tool_timer_end", 0L)
    val ss = Prefs.l(ctx, "tool_sw_start", 0L)
    var mins by remember { mutableStateOf("10") }
    val overlayOk = Settings.canDrawOverlays(ctx)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("ابزارها", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Section("بهینه‌ساز باتری", Help.OPT) {
            if (!scanned) {
                Text("در حال بررسی…", color = Muted)
            } else {
                Text("امتیاز بهینگی: ${score}٪".fa(), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = scoreColor(score))
                LinearProgressIndicator(
                    progress = { score / 100f }, color = scoreColor(score),
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(5.dp))
                )
                if (issues.isEmpty()) Text("✅ مورد خاصی برای بهینه‌سازی پیدا نشد؛ همه‌چی خوبه.", color = Green)
                issues.forEach { s ->
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("⚠️ " + s.title, fontWeight = FontWeight.Bold)
                        Text(s.detail, fontSize = 12.sp, color = Muted)
                        val it2 = s.intent
                        if (it2 != null) OutlinedButton(onClick = { safeStart(ctx, it2) }) { Text(s.action) }
                    }
                }
            }
            Button(onClick = { rescan++ }) { Text("اسکن دوباره") }
        }

        Section("تایمر و کرنومتر (روی جزیره)", Help.TOOLS) {
            if (!overlayOk) Text("⚠️ برای نمایش روی جزیره، از تنظیمات ← جزیره دسترسی «نمایش روی برنامه‌های دیگر» رو بده.", fontSize = 12.sp, color = Orange)
            if (te > 0L) {
                Text("⏳ " + Fmt.clock(((te - now) / 1000).coerceAtLeast(0)).fa(), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Orange)
            } else if (ss > 0L) {
                Text("⏱ " + Fmt.clock(((now - ss) / 1000).coerceAtLeast(0)).fa(), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Blue)
            }
            Text("تایمر", color = Muted)
            Chips(listOf("1" to "۱ دقیقه", "5" to "۵ دقیقه", "10" to "۱۰ دقیقه", "15" to "۱۵ دقیقه", "30" to "۳۰ دقیقه", "60" to "۶۰ دقیقه"), mins) { mins = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { BatteryService.send(ctx, BatteryService.A_TIMER, mins.toInt() * 60) }) { Text("شروع تایمر") }
                OutlinedButton(onClick = { BatteryService.send(ctx, BatteryService.A_SW_START) }) { Text("شروع کرنومتر") }
                OutlinedButton(onClick = { BatteryService.send(ctx, BatteryService.A_STOP) }) { Text("توقف") }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ───────────── پیش‌نمایش‌ها ─────────────

@Composable
fun NotifPreview(theme: String) {
    val shape = RoundedCornerShape(18.dp)
    val bg = when (theme) {
        "gradient" -> Modifier.background(Brush.linearGradient(listOf(Color(0xFF0F9D58), Color(0xFF14532D))), shape)
        "neon" -> Modifier.background(Color.Black, shape).border(2.dp, Green, shape)
        else -> Modifier.background(Brush.linearGradient(listOf(Color(0xFF12261B), Color(0xFF0A120E))), shape)
            .border(1.dp, Color(0xFF2A5A3D), shape)
    }
    val accent = if (theme == "gradient") Color.White else Green
    Column(Modifier.fillMaxWidth().then(bg).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row {
            Text("⚡ در حال شارژ", Modifier.weight(1f), color = accent, fontWeight = FontWeight.Bold)
            Text("۸٪", color = accent, fontWeight = FontWeight.Bold)
        }
        Text("۵۲۰۰ mA", color = accent, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        LinearProgressIndicator(
            progress = { 0.08f }, color = accent, trackColor = Color(0x33FFFFFF),
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp))
        )
        Text("⏱ تا پر شدن ≈ ۱ ساعت و ۴۰ دقیقه", color = Color.White, fontSize = 12.sp)
    }
}

@Composable
fun IslandPreview() {
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier.clip(shape).background(Color.Black).border(1.dp, Green, shape).padding(horizontal = 18.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("⚡", fontSize = 18.sp)
        Column(Modifier.padding(start = 10.dp)) {
            Text("در حال شارژ", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("۵۲۰۰ mA • ۲۰.۸ W", fontSize = 11.sp, color = Muted)
        }
    }
}

// ───────────── تنظیمات ─────────────

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var notifOk by remember { mutableStateOf(true) }
    var overlayOk by remember { mutableStateOf(false) }
    var usageOk by remember { mutableStateOf(false) }
    var batOk by remember { mutableStateOf(false) }
    var listenerOk by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            notifOk = Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            overlayOk = Settings.canDrawOverlays(ctx)
            usageOk = UsageTracker.hasAccess(ctx)
            batOk = ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
            listenerOk = MediaWatcher.enabled(ctx)
            delay(1000)
        }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    var ringTick by remember { mutableIntStateOf(0) }
    val ringLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val d = res.data
        if (d != null) {
            @Suppress("DEPRECATION")
            val u = d.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            if (u != null) {
                Prefs.putS(ctx, "alert_uri", u.toString())
                Prefs.putS(ctx, "alert_mode", "custom")
                ringTick++
            }
        }
    }
    var pv by remember { mutableIntStateOf(0) }
    val animOpts = listOf("spring" to "فنری", "stretch" to "کشسان", "slide" to "کشویی", "fade" to "محو", "pulse" to "ضربانی")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("تنظیمات", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Section("ظاهر برنامه (تم)") {
            ThemePicker()
        }

        Section("عمومی", Help.S_GENERAL) {
            SwitchRow("فعال بودن برنامه", "svc_enabled", true, "اگه خاموش باشه هیچ‌چیز در پس‌زمینه اجرا نمیشه") {
                if (it) BatteryService.start(ctx) else BatteryService.stop(ctx)
            }
            StepRow("فاصله‌ی به‌روزرسانی (صفحه روشن)", "interval", 3, 1, 10, 1, "ثانیه", Help.S_INTERVAL)
            SwitchRow("کم‌مصرف خودکار در باتری کم", "eco_low", true, "زیر ۲۰٪ مصرف خود برنامه ۳ برابر کمتر میشه", Help.S_ECO)
            SwitchRow("ثبت تاریخچه برای نمودار", "hist_on", true, null, Help.S_HIST)
        }

        Section("نوار وضعیت (عدد زنده کنار آیکن‌ها)", Help.S_ICON) {
            SwitchRow("نمایش عدد به‌جای آیکن باتری", "icon_on", true)
            ChoiceRow("وقتی به شارژر وصله، نشون بده:", "icon_charge", "current", Fmt.metrics)
            ChoiceRow("وقتی به شارژر وصل نیست، نشون بده:", "icon_discharge", "current", Fmt.metrics)
            ChoiceRow(
                "خط پایین آیکن", "icon_sub", "unit",
                listOf("unit" to "واحد (mA)", "voltage" to "ولتاژ", "temp" to "دما", "percent" to "درصد", "none" to "هیچی"),
                Help.S_ICON_SUB
            )
        }

        Section("اعلان باتری (قالب و ظاهر)", Help.S_NOTIF) {
            SwitchRow("نمایش اعلان سفارشی", "notif_on", true, "اگه خاموش باشه اعلان ساده‌ی متنی نشون داده میشه") { pv++ }
            NotifPreviewLive(pv)
            ChoiceRow(
                "قالب اعلان", "n_template", "card",
                listOf("system" to "ساده (سیستمی)", "compact" to "فشرده", "card" to "کارت", "graphic" to "گرافیکی"),
                Help.S_TPL, 0
            ) { pv++ }
            ChoiceRow(
                "طرح (رنگ و حالت)", "n_look", "modern",
                listOf("modern" to "مدرن", "gradient" to "گرادیانت", "neon" to "نئون", "classic" to "کلاسیک تیره", "paper" to "کلاسیک روشن"),
                null, 0
            ) { pv++ }
            SwitchRow("حالت سازگار (ضدبریدگی)", "n_compat", NotifStyles.defaultCompat(), "در حالت باز و بسته یک ارتفاع جمع‌وجور؛ برای شیائومی/هایپراواس", Help.S_COMPAT) { pv++ }
            StepRow("ارتفاع نوار جمع‌وجور (فاصله‌ی بالا و پایین)", "n_pad_c", 3, 0, 14, 1, "dp") { pv++ }
            StepRow("ارتفاع کارت بزرگ (فاصله‌ی بالا و پایین)", "n_pad_b", 12, 4, 28, 2, "dp") { pv++ }
            StepRow("اندازه‌ی متن", "n_text", 100, 70, 150, 10, "٪") { pv++ }
            StepRow("گردی گوشه‌ها", "n_corner", 20, 0, 36, 4, "dp") { pv++ }
            Text("موارد نمایشی", color = Muted)
            SwitchRow("ولتاژ", "n_voltage", true) { pv++ }
            SwitchRow("توان (وات)", "n_power", true) { pv++ }
            SwitchRow("دما", "n_temp", true) { pv++ }
            SwitchRow("سلامت باتری (کارت بزرگ و ساده)", "n_health", true) { pv++ }
            SwitchRow("زمان تقریبی تا پر/خالی شدن", "n_time", true, null, Help.ETA) { pv++ }
        }

        Section("جزیره‌ی داینامیک", Help.S_ISLAND) {
            SwitchRow("فعال‌سازی جزیره", "isl_on", false, "نیاز به دسترسی «نمایش روی برنامه‌های دیگر»")
            IslandPreview()
            PermRow("نمایش روی برنامه‌های دیگر", overlayOk) {
                safeStart(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("مخصوص شیائومی/هایپراواس", Modifier.weight(1f), color = Muted)
                InfoIcon("شیائومی / هایپراواس", Help.S_MIUI)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { openMiuiPerms(ctx) }) { Text("مجوزهای برنامه") }
                OutlinedButton(onClick = { openAutostart(ctx) }) { Text("شروع خودکار") }
            }
            ChoiceRow("نوع انیمیشن", "isl_anim", "spring", animOpts)
            SwitchRow("نمایش هنگام وصل شدن شارژر", "isl_plug", true)
            SwitchRow("نمایش هنگام جدا شدن شارژر", "isl_unplug", true)
            SwitchRow("نمایش هنگام شارژ کامل", "isl_full", true)
            SwitchRow("نمایش هنگام دمای بالا", "isl_hot", true)
            SwitchRow("نمایش موسیقی در حال پخش", "isl_music", true, null, Help.S_MUSIC)
            PermRow("دسترسی به اعلان‌ها (برای موسیقی)", listenerOk) {
                safeStart(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            SwitchRow("همیشه نمایان باشه (نمایش زنده)", "isl_always", false, "درصد و سرعت شارژ زنده بالای صفحه می‌مونه")
            StepRow("مدت نمایش", "isl_sec", 4, 2, 15, 1, "ثانیه")
            StepRow("فاصله از بالای صفحه", "isl_y", 8, 0, 60, 2, "dp")
            Button(onClick = { BatteryService.send(ctx, BatteryService.A_TEST) }) { Text("تست جزیره") }
        }

        Section("هشدارها", Help.S_ALERT) {
            SwitchRow("هشدار شارژ کامل", "alert_full", true)
            SwitchRow("هشدار دمای بالا", "alert_hot", true)
            StepRow("حد دمای هشدار", "hot_c", 42, 35, 55, 1, "درجه")
            SwitchRow("هشدار حد شارژ (برای سلامت باتری)", "alert_limit", false, "فقط هشدار میده؛ قطع شارژ بدون روت ممکن نیست", Help.S_LIMIT)
            StepRow("حد شارژ", "limit_pct", 80, 50, 100, 5, "٪")
            SwitchRow("هشدار برنامه‌ی پرمصرف", "alert_usage", false, "نیاز به دسترسی داده‌های استفاده")
            StepRow("هشدار بعد از", "usage_min", 120, 15, 480, 15, "دقیقه")
            ChoiceRow(
                "صدای هشدار", "alert_mode", "sound",
                listOf("sound" to "پیش‌فرض", "silent" to "بی‌صدا", "vibrate" to "فقط ارتعاش", "custom" to "صدای دلخواه"),
                Help.S_SOUND, ringTick
            )
            OutlinedButton(onClick = {
                val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_ALARM)
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                ringLauncher.launch(intent)
            }) { Text("انتخاب صدای دلخواه") }
        }

        Section("دسترسی‌ها") {
            PermRow("اعلان‌ها", notifOk) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            PermRow("داده‌های استفاده‌ی برنامه‌ها", usageOk) { safeStart(ctx, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            PermRow("بدون محدودیت باتری (برای پایدار ماندن)", batOk) {
                safeStart(ctx, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun ThemePicker() {
    val ctx = LocalContext.current
    val cur = Themes.cur
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Themes.all.forEach { t ->
            val sel = t.id == cur.id
            Column(
                Modifier.clip(RoundedCornerShape(16.dp)).background(t.bg)
                    .border(if (sel) 2.dp else 1.dp, if (sel) t.charge else t.surfaceVar, RoundedCornerShape(16.dp))
                    .clickable { Themes.set(ctx, t.id) }.padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(Modifier.size(18.dp).clip(CircleShape).background(t.charge))
                    Box(Modifier.size(18.dp).clip(CircleShape).background(t.discharge))
                    Box(Modifier.size(18.dp).clip(CircleShape).background(t.surface))
                }
                Text(t.name, color = t.text, fontSize = 12.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}
