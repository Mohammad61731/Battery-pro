package com.batterypro

import android.content.Context
import java.io.File

object HistoryStore {
    data class P(val t: Long, val pct: Int, val ma: Int, val mv: Int, val temp: Float, val ch: Boolean)

    private fun f(c: Context) = File(c.filesDir, "history.csv")

    @Synchronized
    fun add(c: Context, i: BatteryInfo) {
        val file = f(c)
        file.appendText("${System.currentTimeMillis()},${i.percent},${i.currentMa},${i.voltageMv},${i.tempC},${if (i.plugged) 1 else 0}\n")
        if (file.length() > 120_000) {
            val lines = file.readLines().takeLast(1440)
            file.writeText(lines.joinToString("\n") + "\n")
        }
    }

    @Synchronized
    fun read(c: Context, hours: Int): List<P> {
        val file = f(c)
        if (!file.exists()) return emptyList()
        val from = System.currentTimeMillis() - hours * 3600_000L
        return file.readLines().mapNotNull { l ->
            val p = l.split(",")
            if (p.size < 6) null else try {
                P(p[0].toLong(), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toFloat(), p[5] == "1")
            } catch (e: Exception) {
                null
            }
        }.filter { it.t >= from }
    }
}
