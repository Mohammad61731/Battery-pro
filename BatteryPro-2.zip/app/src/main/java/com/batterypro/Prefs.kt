package com.batterypro

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("bp_settings", Context.MODE_PRIVATE)
    fun b(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun s(c: Context, k: String, d: String) = sp(c).getString(k, d) ?: d
    fun i(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun l(c: Context, k: String, d: Long) = sp(c).getLong(k, d)
    fun putB(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun putS(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun putI(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun putL(c: Context, k: String, v: Long) = sp(c).edit().putLong(k, v).apply()
    fun hash(c: Context): Int = sp(c).all.hashCode()
}
