package com.batterypro

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import androidx.core.app.NotificationManagerCompat

object MediaWatcher {
    data class Track(val title: String, val artist: String) {
        val key: String get() = "$title|$artist"
    }

    fun enabled(c: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

    fun playing(c: Context): Track? {
        if (!enabled(c)) return null
        return try {
            val msm = c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(c, NotifListener::class.java))
            val s = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: return null
            val md = s.metadata ?: return null
            val t = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
            val a = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
            Track(t, a)
        } catch (e: Exception) {
            null
        }
    }
}
