package com.batterypro

import android.service.notification.NotificationListenerService

/** فقط برای گرفتن دسترسی خوندن وضعیت پخش موسیقی (جزیره)؛ هیچ اعلانی ذخیره یا خونده نمیشه */
class NotifListener : NotificationListenerService()
