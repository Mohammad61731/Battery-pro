package com.batterypro

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

data class BpTheme(
    val id: String,
    val name: String,
    val dark: Boolean,
    val bg: Color,
    val surface: Color,
    val surfaceVar: Color,
    val text: Color,
    val muted: Color,
    val charge: Color,       // رنگ اصلی (موقع شارژ)
    val discharge: Color     // رنگ دوم (موقع مصرف)
)

object Themes {
    val all = listOf(
        BpTheme("aurora", "شفق سبز", true, Color(0xFF0B0F14), Color(0xFF151B23), Color(0xFF1E2630), Color.White, Color(0xFF9AA4B2), Color(0xFF4ADE80), Color(0xFF60A5FA)),
        BpTheme("ocean", "اقیانوس", true, Color(0xFF06121F), Color(0xFF0D2236), Color(0xFF16324D), Color.White, Color(0xFF8FA6BF), Color(0xFF22D3EE), Color(0xFF818CF8)),
        BpTheme("sunset", "غروب", true, Color(0xFF160D12), Color(0xFF261720), Color(0xFF35212D), Color.White, Color(0xFFB8A1AD), Color(0xFFFB923C), Color(0xFFF472B6)),
        BpTheme("violet", "بنفشه", true, Color(0xFF0F0B1C), Color(0xFF1A1430), Color(0xFF281F47), Color.White, Color(0xFFA9A1C7), Color(0xFFC084FC), Color(0xFF60A5FA)),
        BpTheme("cyber", "سایبر", true, Color(0xFF07070F), Color(0xFF12122A), Color(0xFF1D1D40), Color.White, Color(0xFF8E8EB5), Color(0xFF00F5D4), Color(0xFFFF3CAC)),
        BpTheme("amoled", "مشکی خالص", true, Color(0xFF000000), Color(0xFF0C0C0C), Color(0xFF1A1A1A), Color.White, Color(0xFF8A8A8A), Color(0xFF4ADE80), Color(0xFF60A5FA)),
        BpTheme("light", "روشن", false, Color(0xFFF3F5F8), Color(0xFFFFFFFF), Color(0xFFE6EAF0), Color(0xFF111827), Color(0xFF6B7280), Color(0xFF16A34A), Color(0xFF2563EB))
    )

    var cur by mutableStateOf(all[0])

    fun byId(id: String): BpTheme = all.firstOrNull { it.id == id } ?: all[0]

    fun load(c: Context) {
        cur = byId(Prefs.s(c, "app_theme", "aurora"))
    }

    fun set(c: Context, id: String) {
        Prefs.putS(c, "app_theme", id)
        cur = byId(id)
    }

    /** رنگ‌های نوتیفیکیشن (بدون Compose) */
    fun chargeInt(c: Context): Int = byId(Prefs.s(c, "app_theme", "aurora")).charge.toArgbInt()
    fun dischargeInt(c: Context): Int = byId(Prefs.s(c, "app_theme", "aurora")).discharge.toArgbInt()
}

fun Color.toArgbInt(): Int {
    val a = (alpha * 255f + 0.5f).toInt()
    val r = (red * 255f + 0.5f).toInt()
    val g = (green * 255f + 0.5f).toInt()
    val b = (blue * 255f + 0.5f).toInt()
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}
