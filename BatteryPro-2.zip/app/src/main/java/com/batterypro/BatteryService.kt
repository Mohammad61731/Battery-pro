package com.batterypro

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat
import java.util.Locale

class BatteryService : Service() {
    companion object {
        const val ID_LIVE = 1
        const val A_TEST = "TEST_ISLAND"
        const val A_TIMER = "TIMER_START"
        const val A_SW_START = "SW_START"
        const val A_STOP = "TOOLS_STOP"
        const val EXTRA_SEC = "sec"

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, BatteryService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, BatteryService::class.java))
        }

        fun send(c: Context, action: String, sec: Int = 0) {
            ContextCompat.startForegroundService(
                c, Intent(c, BatteryService::class.java).setAction(action).putExtra(EXTRA_SEC, sec)
            )
        }
    }

    private val GREEN = Color.parseColor("#4ADE80")
    private val BLUE = Color.parseColor("#60A5FA")
    private val RED = Color.parseColor("#F87171")
    private val ORANGE = Color.parseColor("#FB923C")
    private val PURPLE = Color.parseColor("#C084FC")

    private val h = Handler(Looper.getMainLooper())
    private lateinit var nm: NotificationManager
    private lateinit var island: IslandController
    private val startWhen = System.currentTimeMillis()   // زمان ثابت => جای نوتیف جابه‌جا نمیشه
    private var screenOn = true
    private var lastPlugged: Boolean? = null
    private var lastSig = ""
    private var nFull = false
    private var nHot = false
    private var nLimit = false
    private var chgDone = true
    private var lastHist = 0L
    private var lastUsage = 0L
    private var tickMs = 3000L
    private var lastTrack = ""

    private val tick = object : Runnable {
        override fun run() {
            update()
            if (screenOn) h.postDelayed(this, tickMs)
        }
    }

    private val tools = object : Runnable {
        override fun run() {
            if (toolsTick() && screenOn) h.postDelayed(this, 1000)
        }
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    screenOn = false
                    h.removeCallbacks(tick)
                    h.removeCallbacks(tools)
                }
                Intent.ACTION_SCREEN_ON -> {
                    screenOn = true
                    h.removeCallbacks(tick)
                    h.removeCallbacks(tools)
                    h.post(tick)
                    h.post(tools)
                }
                Intent.ACTION_BATTERY_CHANGED -> if (!screenOn) update()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        Notif.channels(this)
        island = IslandController(this)
        screenOn = getSystemService(PowerManager::class.java).isInteractive
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        ContextCompat.registerReceiver(this, rx, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val info = BatteryReader.read(this)
        val n = buildNotif(info)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_LIVE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_LIVE, n)
        }
        val now = System.currentTimeMillis()
        when (intent?.action) {
            A_TEST -> island.flash("⚡", "تست جزیره", "${Fmt.long(info, "current")} • ${info.percent}٪".fa(), GREEN)
            A_TIMER -> {
                val sec = intent?.getIntExtra(EXTRA_SEC, 60) ?: 60
                Prefs.putL(this, "tool_sw_start", 0L)
                Prefs.putL(this, "tool_timer_end", now + sec * 1000L)
                TimerReceiver.schedule(this, now + sec * 1000L)
            }
            A_SW_START -> {
                TimerReceiver.cancel(this)
                Prefs.putL(this, "tool_timer_end", 0L)
                Prefs.putL(this, "tool_sw_start", now)
            }
            A_STOP -> {
                TimerReceiver.cancel(this)
                Prefs.putL(this, "tool_timer_end", 0L)
                Prefs.putL(this, "tool_sw_start", 0L)
                island.remove()
            }
        }
        h.removeCallbacks(tick)
        h.removeCallbacks(tools)
        h.post(tick)
        h.post(tools)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { unregisterReceiver(rx) } catch (e: Exception) { }
        island.remove()
        super.onDestroy()
    }

    /** تایمر و کرنومتر روی جزیره؛ true یعنی هنوز فعاله */
    private fun toolsTick(): Boolean {
        val now = System.currentTimeMillis()
        val te = Prefs.l(this, "tool_timer_end", 0L)
        val ss = Prefs.l(this, "tool_sw_start", 0L)
        if (te > 0L) {
            val left = (te - now) / 1000
            if (left <= 0L) {
                TimerReceiver.finish(this)
                TimerReceiver.cancel(this)
                island.remove()
                island.flash("⏰", "تایمر تمام شد", "زمان تموم شد", ORANGE)
                return false
            }
            island.persistent("⏳", Fmt.clock(left).fa(), "تایمر", ORANGE)
            return true
        }
        if (ss > 0L) {
            island.persistent("⏱", Fmt.clock((now - ss) / 1000).fa(), "کرنومتر", BLUE)
            return true
        }
        return false
    }

    private fun update() {
        val i = BatteryReader.read(this)
        val islOn = Prefs.b(this, "isl_on", false)
        val toolsOn = Prefs.l(this, "tool_timer_end", 0L) > 0L || Prefs.l(this, "tool_sw_start", 0L) > 0L

        // کم‌مصرف: وقتی باتری زیر ۲۰٪ و بدون شارژه، فاصله‌ی به‌روزرسانی ۳ برابر میشه
        val base = Prefs.i(this, "interval", 3) * 1000L
        tickMs = if (Prefs.b(this, "eco_low", true) && !i.plugged && i.percent < 20) base * 3 else base

        // وصل/قطع شارژر
        val lp = lastPlugged
        if (lp == null) {
            if (i.plugged && Prefs.l(this, "sess_start_t", 0L) == 0L) Session.start(this, i.percent)
        } else if (lp != i.plugged) {
            BatteryReader.resetEma()
            if (i.plugged) {
                nFull = false
                nLimit = false
                chgDone = false
                Session.start(this, i.percent)
                if (islOn && Prefs.b(this, "isl_plug", true))
                    island.flash("⚡", "در حال شارژ", "${Fmt.long(i, "current")} • ${Fmt.long(i, "power")}".fa(), GREEN)
            } else {
                Session.end(this, i.percent)
                if (islOn && Prefs.b(this, "isl_unplug", true))
                    island.flash("🔌", "شارژر جدا شد", "${i.percent}٪".fa(), BLUE)
            }
        }
        lastPlugged = i.plugged

        // تحلیل خودکار شارژر (بعد از جا افتادن عددها، نه لحظه‌ی اول اتصال)
        if (i.plugged && !chgDone && !i.settling && Prefs.b(this, "chg_auto", true) &&
            System.currentTimeMillis() - BatteryReader.plugSince() >= 20_000L
        ) {
            chgDone = true
            val rep = ChargerAnalyzer.analyze(BatteryReader.chargeSamples(), i, Prefs.i(this, "factory_w", 25))
            if (rep != null) {
                val title = "⚡ شارژر: ${rep.tierLabel} ≈ ${rep.watt()} وات".fa()
                val short = (rep.verdict + " • " + String.format(Locale.US, "%.2f", rep.avgMv / 1000f) + " V • " + rep.voltClass).fa()
                Notif.info(this, 13, title, short, (rep.lines.joinToString("\n") + "\n\n" + "رده‌ی ولتاژ: " + rep.voltClass).fa())
                if (islOn && Prefs.b(this, "isl_plug", true))
                    island.flash("⚡", rep.tierLabel, "≈ ${rep.watt()} W • ${rep.verdict}".fa(), if (rep.level == 0) GREEN else if (rep.level == 1) ORANGE else RED)
            }
        }
        // شارژ کامل
        if (i.plugged && (i.full || i.percent >= 100) && !nFull) {
            nFull = true
            if (Prefs.b(this, "alert_full", true)) Notif.alert(this, 10, "✅ شارژ کامل شد", "باتری ۱۰۰٪ است؛ شارژر رو جدا کن.")
            if (islOn && Prefs.b(this, "isl_full", true)) island.flash("✅", "شارژ کامل شد", "۱۰۰٪", GREEN)
        }
        // حد شارژ
        if (i.plugged && Prefs.b(this, "alert_limit", false)) {
            val lim = Prefs.i(this, "limit_pct", 80)
            if (i.percent >= lim && !nLimit) {
                nLimit = true
                Notif.alert(this, 12, "🔋 به حد شارژ رسید", "${i.percent}٪ شد؛ برای سلامت باتری شارژر رو جدا کن.".fa())
            }
        }
        // دمای بالا
        val hotC = Prefs.i(this, "hot_c", 42)
        if (i.tempC >= hotC) {
            if (!nHot) {
                nHot = true
                val t = String.format(Locale.US, "%.1f °C", i.tempC).fa()
                if (Prefs.b(this, "alert_hot", true)) Notif.alert(this, 11, "🔥 دمای باتری بالاست", t)
                if (islOn && Prefs.b(this, "isl_hot", true)) island.flash("🔥", "دمای بالا", t, RED)
            }
        } else if (i.tempC < hotC - 3) nHot = false

        // جزیره (وقتی تایمر/کرنومتر فعاله اونا اولویت دارن)
        if (!toolsOn) {
            val tr = if (islOn && screenOn && Prefs.b(this, "isl_music", true)) MediaWatcher.playing(this) else null
            if (!islOn) {
                if (island.isPersistent) island.remove()
            } else if (Prefs.b(this, "isl_always", false)) {
                if (tr != null) {
                    island.persistent("🎵", tr.title, tr.artist.ifEmpty { "در حال پخش" }, PURPLE)
                } else {
                    val key = if (i.plugged) "icon_charge" else "icon_discharge"
                    island.persistent(
                        if (i.plugged) "⚡" else "🔋",
                        Fmt.long(i, Prefs.s(this, key, "current")).fa(),
                        "${i.percent}٪ • ${Fmt.long(i, "temp")}".fa(),
                        if (i.plugged) GREEN else BLUE
                    )
                }
            } else {
                if (island.isPersistent) island.remove()
                if (tr != null && tr.key != lastTrack) {
                    island.flash("🎵", tr.title, tr.artist.ifEmpty { "در حال پخش" }, PURPLE)
                }
            }
            lastTrack = tr?.key ?: ""
        }

        // نوتیفیکیشن + آیکن نوار وضعیت + ویجت (فقط وقتی چیزی عوض شده)
        val sig = listOf(
            i.percent, i.plugged, i.currentMa, i.voltageMv, (i.tempC * 10).toInt(), i.etaMin, i.settling, Prefs.hash(this)
        ).joinToString("|")
        if (sig != lastSig) {
            lastSig = sig
            nm.notify(ID_LIVE, buildNotif(i))
            BatteryWidget.refresh(this, i)
        }

        val now = System.currentTimeMillis()
        if (Prefs.b(this, "hist_on", true) && now - lastHist > 60_000) {
            lastHist = now
            HistoryStore.add(this, i)
        }
        if (now - lastUsage > 15 * 60_000L) {
            lastUsage = now
            Thread {
                try {
                    UsageTracker.saveToday(this)
                    if (Prefs.b(this, "alert_usage", false)) UsageTracker.alertCheck(this)
                } catch (e: Exception) { }
            }.start()
        }
    }

    private fun fit(p: Paint, t: String, start: Float, maxW: Int) {
        var s = start
        p.textSize = s
        while (p.measureText(t) > maxW && s > 14f) {
            s -= 2f
            p.textSize = s
        }
    }

    /** آیکن نوار وضعیت: خط بالا مقدار، خط پایین واحد (مثلاً 350 / mA) */
    private fun textIcon(top: String, bottom: String): IconCompat {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        if (bottom.isEmpty()) {
            fit(p, top, 86f, size - 2)
            c.drawText(top, size / 2f, size / 2f - (p.descent() + p.ascent()) / 2f, p)
        } else {
            fit(p, top, 54f, size - 2)
            c.drawText(top, size / 2f, 27f - (p.descent() + p.ascent()) / 2f, p)
            fit(p, bottom, 38f, size - 2)
            c.drawText(bottom, size / 2f, 73f - (p.descent() + p.ascent()) / 2f, p)
        }
        return IconCompat.createWithBitmap(bmp)
    }

    private fun buildNotif(i: BatteryInfo): Notification {
        val charging = i.plugged
        val key = if (charging) "icon_charge" else "icon_discharge"
        val metric = Prefs.s(this, key, "current")
        val b = NotificationCompat.Builder(this, Notif.CH_LIVE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setWhen(startWhen)
            .setShowWhen(false)
            .setSortKey("a")
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(Notif.openApp(this))

        if (Prefs.b(this, "icon_on", true)) {
            val bottom = when (Prefs.s(this, "icon_sub", "unit")) {
                "unit" -> Fmt.unit(metric)
                "voltage" -> Fmt.short(i, "voltage") + "V"
                "temp" -> Fmt.short(i, "temp")
                "percent" -> i.percent.toString() + "%"
                else -> ""
            }
            b.setSmallIcon(textIcon(Fmt.short(i, metric), bottom))
        } else {
            b.setSmallIcon(R.drawable.ic_stat)
        }

        if (Prefs.b(this, "notif_on", true)) {
            NotifStyles.applyTo(this, b, i, metric)
        } else {
            b.setContentTitle("${Fmt.long(i, metric)} • ${i.percent}٪".fa()).setContentText(NotifStyles.statusText(i))
        }
        return b.build()
    }
}
