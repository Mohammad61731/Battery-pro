package com.batterypro

import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

object Optimizer {
    data class Issue(val title: String, val detail: String, val penalty: Int, val action: String, val intent: Intent?)

    fun scan(c: Context, i: BatteryInfo, top: List<UsageTracker.AppUse>): List<Issue> {
        val out = mutableListOf<Issue>()
        val cr = c.contentResolver

        val br = try { Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { -1 }
        val auto = try {
            Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE) == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
        } catch (e: Exception) { false }
        if (br in 201..255 && !auto) {
            out.add(Issue("روشنایی صفحه خیلی بالاست", "صفحه بیشترین سهم مصرف باتریه. روشنایی خودکار یا کمتر کردنش چند ساعت بیشتر شارژ میده.", 12, "تنظیمات نمایشگر", Intent(Settings.ACTION_DISPLAY_SETTINGS)))
        }

        val to = try { Settings.System.getInt(cr, Settings.System.SCREEN_OFF_TIMEOUT) } catch (e: Exception) { 30000 }
        if (to > 60000) {
            out.add(Issue("زمان خاموش شدن صفحه طولانیه", "صفحه بیشتر از ۱ دقیقه روشن می‌مونه. ۳۰ ثانیه یا ۱ دقیقه بهتره.", 6, "تنظیمات نمایشگر", Intent(Settings.ACTION_DISPLAY_SETTINGS)))
        }

        val pm = c.getSystemService(PowerManager::class.java)
        if (!pm.isPowerSaveMode && !i.plugged && i.percent < 30) {
            out.add(Issue("حالت صرفه‌جویی خاموشه", "باتری کمه؛ حالت صرفه‌جویی مصرف پس‌زمینه رو کم می‌کنه.", 10, "حالت صرفه‌جویی", Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)))
        }

        if (Build.VERSION.SDK_INT >= 28) {
            val lm = c.getSystemService(LocationManager::class.java)
            if (lm != null && lm.isLocationEnabled && !i.plugged) {
                out.add(Issue("موقعیت مکانی روشنه", "اگه لازم نداری خاموشش کن؛ GPS و شبکه مصرف دائمی دارن.", 4, "تنظیمات موقعیت", Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
            }
        }

        if (i.tempC >= 40f) {
            out.add(Issue("دمای باتری بالاست (${i.tempC.toInt()} درجه)", "گرما سرعت شارژ رو کم می‌کنه و به باتری آسیب می‌زنه. کاور رو بردار و برنامه‌های سنگین رو ببند.", 15, "", null))
        }

        if (i.plugged && i.percent >= 90) {
            out.add(Issue("باتری تقریباً پره و هنوز به شارژره", "نگه داشتن باتری روی ۱۰۰٪ برای عمرش خوب نیست. بهتره حدود ۸۰٪ جداش کنی.", 5, "", null))
        }

        top.filter { !it.system && it.minutes >= 90 && it.pkg != c.packageName }.take(3).forEach { a ->
            out.add(Issue("برنامه‌ی پرمصرف: ${a.label}", "امروز ${Fmt.dur(a.minutes)} باز بوده. اگه لازم نیست ببندش یا محدودش کن.", 8, "اطلاعات برنامه", Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg))))
        }
        return out
    }
}
