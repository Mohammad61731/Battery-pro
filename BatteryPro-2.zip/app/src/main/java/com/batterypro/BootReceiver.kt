package com.batterypro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.b(c, "svc_enabled", true)) BatteryService.start(c)
    }
}
