package com.batterypro

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import java.util.Locale

/** پالت رنگ یک اعلان */
data class Pal(
    val accent: Int, val text: Int, val muted: Int, val track: Int,
    val bg1: Int, val bg2: Int, val stroke: Int, val strokeW: Float, val bar: Int
)

/** ابزار کشیدن بیت‌مپ‌ها (پس‌زمینه، نوار، حلقه، نمودار مینی) */
object Gfx {
    private val cache = HashMap<String, Bitmap>()

    fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * (1 - t) + Color.red(b) * t).toInt()
        val g = (Color.green(a) * (1 - t) + Color.green(b) * t).toInt()
        val bl = (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    fun bg(w: Int, h: Int, p: Pal, radius: Float): Bitmap {
        val key = "bg|$w|$h|${p.bg1}|${p.bg2}|${p.stroke}|${p.strokeW}|$radius"
        cache[key]?.let { return it }
        if (cache.size > 24) cache.clear()
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val inset = p.strokeW * 2f + 1f
        val rect = RectF(inset, inset, w - inset, h - inset)
        val r = radius.coerceAtMost(rect.height() / 2f)
        paint.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), p.bg1, p.bg2, Shader.TileMode.CLAMP)
        cv.drawRoundRect(rect, r, r, paint)
        if (p.strokeW > 0f) {
            paint.shader = null
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = p.strokeW * 2f
            paint.color = p.stroke
            cv.drawRoundRect(rect, r, r, paint)
        }
        cache[key] = b
        return b
    }

    fun bar(w: Int, h: Int, pct: Int, color: Int, track: Int): Bitmap {
        val key = "bar|$w|$h|$pct|$color|$track"
        cache[key]?.let { return it }
        if (cache.size > 24) cache.clear()
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = h / 2f
        paint.color = track
        cv.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, paint)
        if (pct > 0) {
            paint.color = color
            val fw = (w * pct.coerceIn(0, 100) / 100f).coerceAtLeast(h.toFloat())
            cv.drawRoundRect(RectF(0f, 0f, fw, h.toFloat()), r, r, paint)
        }
        cache[key] = b
        return b
    }

    fun ring(size: Int, pct: Int, color: Int, track: Int): Bitmap {
        val key = "ring|$size|$pct|$color|$track"
        cache[key]?.let { return it }
        if (cache.size > 24) cache.clear()
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val sw = size * 0.13f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = sw
        paint.strokeCap = Paint.Cap.ROUND
        val rect = RectF(sw / 2f + 2f, sw / 2f + 2f, size - sw / 2f - 2f, size - sw / 2f - 2f)
        paint.color = track
        cv.drawArc(rect, 135f, 270f, false, paint)
        paint.color = color
        if (pct > 0) cv.drawArc(rect, 135f, 270f * pct.coerceIn(0, 100) / 100f, false, paint)
        cache[key] = b
        return b
    }

    fun spark(w: Int, h: Int, vals: List<Float>, color: Int): Bitmap? {
        if (vals.size < 2) return null
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        val mn = vals.minOrNull() ?: 0f
        val mx = vals.maxOrNull() ?: 1f
        val rng = if (mx - mn > 0.0001f) mx - mn else 1f
        val path = Path()
        val fill = Path()
        vals.forEachIndexed { idx, v ->
            val x = w * idx / (vals.size - 1).toFloat()
            val y = h * 0.1f + h * 0.8f * (1f - (v - mn) / rng)
            if (idx == 0) { path.moveTo(x, y); fill.moveTo(x, h.toFloat()); fill.lineTo(x, y) } else { path.lineTo(x, y); fill.lineTo(x, y) }
        }
        fill.lineTo(w.toFloat(), h.toFloat())
        fill.close()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), (color and 0x00FFFFFF) or 0x66000000, (color and 0x00FFFFFF), Shader.TileMode.CLAMP)
        cv.drawPath(fill, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = h * 0.05f + 2f
        paint.strokeJoin = Paint.Join.ROUND
        paint.color = color
        cv.drawPath(path, paint)
        return b
    }
}

/** ساخت انواع قالب اعلان */
object NotifStyles {
    private const val PX_DP = 2.12f   // هر dp تقریباً چند پیکسل بیت‌مپ پس‌زمینه

    fun defaultCompat(): Boolean {
        val m = Build.MANUFACTURER.lowercase(Locale.US)
        return m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")
    }

    private fun dp(c: Context, v: Float): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun pal(c: Context, i: BatteryInfo): Pal {
        val look = Prefs.s(c, "n_look", "modern")
        val hot = i.tempC >= Prefs.i(c, "hot_c", 42)
        val base = if (hot) 0xFFF87171.toInt() else if (i.plugged) Themes.chargeInt(c) else Themes.dischargeInt(c)
        val white = Color.WHITE
        val black = Color.BLACK
        val dark = 0xFF0B0F14.toInt()
        return when (look) {
            "gradient" -> Pal(white, white, 0xFFE5E7EB.toInt(), 0x44FFFFFF, Gfx.mix(base, black, 0.25f), Gfx.mix(base, black, 0.65f), 0, 0f, white)
            "neon" -> Pal(base, white, 0xFF9AA4B2.toInt(), 0x33FFFFFF, black, black, base, 1.5f, base)
            "classic" -> Pal(base, 0xFFF3F4F6.toInt(), 0xFF9CA3AF.toInt(), 0x33FFFFFF, 0xFF22262C.toInt(), 0xFF22262C.toInt(), 0, 0f, base)
            "paper" -> Pal(Gfx.mix(base, black, 0.3f), 0xFF111827.toInt(), 0xFF6B7280.toInt(), 0x22000000, 0xFFF4F5F7.toInt(), 0xFFF4F5F7.toInt(), 0xFFD1D5DB.toInt(), 1f, Gfx.mix(base, black, 0.15f))
            else -> Pal(base, white, 0xFF9AA4B2.toInt(), 0x33FFFFFF, Gfx.mix(base, dark, 0.86f), Gfx.mix(base, dark, 0.95f), Gfx.mix(base, dark, 0.62f), 1f, base)
        }
    }

    fun statusText(i: BatteryInfo): String = when {
        i.plugged && i.full -> "✅ شارژ کامل"
        i.plugged && i.settling -> "⚡ شارژ • در حال سنجش…"
        i.plugged -> "⚡ در حال شارژ"
        else -> "🔋 در حال مصرف"
    }

    private fun etaText(i: BatteryInfo): String? {
        if (i.settling) return "⏱ در حال سنجش دقیق…"
        if (i.etaMin <= 0 || (i.plugged && i.full)) return null
        return (if (i.plugged) "⏱ تا پر شدن ≈ " else "⏳ تا خالی شدن ≈ ") + Fmt.dur(i.etaMin)
    }

    private fun scale(c: Context): Float = Prefs.i(c, "n_text", 100) / 100f

    private fun radius(c: Context): Float = Prefs.i(c, "n_corner", 20) * PX_DP

    private fun bgBmp(c: Context, p: Pal, hDp: Float): Bitmap {
        val h = (hDp * PX_DP).toInt().coerceIn(60, 900)
        return Gfx.bg(720, h, p, radius(c))
    }

    // ── جمع‌وجور: برای حالت بسته، صفحه‌ی قفل و گوشی‌هایی که ارتفاع اعلان رو محدود می‌کنن ──
    fun compact(c: Context, i: BatteryInfo, metric: String): RemoteViews {
        val rv = RemoteViews(c.packageName, R.layout.notif_compact)
        val p = pal(c, i)
        val s = scale(c)
        val padV = Prefs.i(c, "n_pad_c", 3)
        rv.setViewPadding(R.id.nc_content, dp(c, 12f), dp(c, padV.toFloat()), dp(c, 12f), dp(c, padV.toFloat()))
        rv.setImageViewBitmap(R.id.nc_bg, bgBmp(c, p, 2f * padV + 30f * s + 14f * s))
        rv.setImageViewBitmap(R.id.nc_bar, Gfx.bar(600, 12, i.percent, p.bar, p.track))

        rv.setTextViewText(R.id.nc_main, ((if (i.plugged) "⚡ " else "🔋 ") + Fmt.long(i, metric)).fa())
        rv.setTextColor(R.id.nc_main, p.accent)
        rv.setTextViewTextSize(R.id.nc_main, TypedValue.COMPLEX_UNIT_SP, 18f * s)
        rv.setTextViewText(R.id.nc_percent, "${i.percent}٪".fa())
        rv.setTextColor(R.id.nc_percent, p.accent)
        rv.setTextViewTextSize(R.id.nc_percent, TypedValue.COMPLEX_UNIT_SP, 16f * s)

        val parts = mutableListOf<String>()
        if (Prefs.b(c, "n_voltage", true)) parts.add(Fmt.long(i, "voltage"))
        if (Prefs.b(c, "n_power", true)) parts.add(Fmt.long(i, "power"))
        if (Prefs.b(c, "n_temp", true)) parts.add(Fmt.long(i, "temp"))
        if (Prefs.b(c, "n_time", true)) etaText(i)?.let { parts.add(it) }
        rv.setTextViewText(R.id.nc_line, parts.joinToString("  •  ").fa())
        rv.setTextColor(R.id.nc_line, p.muted)
        rv.setTextViewTextSize(R.id.nc_line, TypedValue.COMPLEX_UNIT_SP, 11f * s)
        rv.setViewVisibility(R.id.nc_line, if (parts.isEmpty()) View.GONE else View.VISIBLE)
        return rv
    }

    // ── کارت بزرگ ──
    fun card(c: Context, i: BatteryInfo, metric: String): RemoteViews {
        val rv = RemoteViews(c.packageName, R.layout.notif_battery)
        val p = pal(c, i)
        val s = scale(c)
        val pad = Prefs.i(c, "n_pad_b", 12)
        rv.setViewPadding(R.id.n_content, dp(c, 14f), dp(c, pad.toFloat()), dp(c, 14f), dp(c, pad.toFloat()))
        rv.setImageViewBitmap(R.id.n_bg, bgBmp(c, p, 2f * pad + 118f * s))
        rv.setImageViewBitmap(R.id.n_bar, Gfx.bar(600, 16, i.percent, p.bar, p.track))

        rv.setTextViewText(R.id.n_status, statusText(i))
        rv.setTextColor(R.id.n_status, p.accent)
        rv.setTextViewTextSize(R.id.n_status, TypedValue.COMPLEX_UNIT_SP, 14f * s)
        rv.setTextViewText(R.id.n_percent, "${i.percent}٪".fa())
        rv.setTextColor(R.id.n_percent, p.accent)
        rv.setTextViewTextSize(R.id.n_percent, TypedValue.COMPLEX_UNIT_SP, 18f * s)
        rv.setTextViewText(R.id.n_main, Fmt.long(i, metric).fa())
        rv.setTextColor(R.id.n_main, p.accent)
        rv.setTextViewTextSize(R.id.n_main, TypedValue.COMPLEX_UNIT_SP, 28f * s)

        val eta = if (Prefs.b(c, "n_time", true)) etaText(i) else null
        rv.setViewVisibility(R.id.n_eta, if (eta != null) View.VISIBLE else View.GONE)
        if (eta != null) {
            rv.setTextViewText(R.id.n_eta, eta.fa())
            rv.setTextColor(R.id.n_eta, p.text)
            rv.setTextViewTextSize(R.id.n_eta, TypedValue.COMPLEX_UNIT_SP, 12f * s)
        }

        fun cell(cc: Int, l: Int, v: Int, key: String, label: String, value: String) {
            rv.setViewVisibility(cc, if (Prefs.b(c, key, true)) View.VISIBLE else View.GONE)
            rv.setTextViewText(l, label)
            rv.setTextColor(l, p.muted)
            rv.setTextViewTextSize(l, TypedValue.COMPLEX_UNIT_SP, 10f * s)
            rv.setTextViewText(v, value.fa())
            rv.setTextColor(v, p.text)
            rv.setTextViewTextSize(v, TypedValue.COMPLEX_UNIT_SP, 13f * s)
        }
        cell(R.id.n_c1, R.id.n_l1, R.id.n_v1, "n_voltage", "ولتاژ", Fmt.long(i, "voltage"))
        cell(R.id.n_c2, R.id.n_l2, R.id.n_v2, "n_power", "توان", Fmt.long(i, "power"))
        cell(R.id.n_c3, R.id.n_l3, R.id.n_v3, "n_temp", "دما", Fmt.long(i, "temp"))
        cell(R.id.n_c4, R.id.n_l4, R.id.n_v4, "n_health", "سلامت", i.health)
        return rv
    }

    // ── گرافیکی: حلقه‌ی درصد + نمودار مینی ──
    private var sparkT = 0L
    private var sparkVals: List<Float> = emptyList()
    private var sparkCharging = false

    private fun sparkData(c: Context, charging: Boolean): List<Float> {
        val now = System.currentTimeMillis()
        if (now - sparkT > 30_000L || sparkCharging != charging) {
            sparkT = now
            sparkCharging = charging
            sparkVals = try {
                val pts = HistoryStore.read(c, 1)
                val v = pts.map { if (charging) it.ma.toFloat() else it.pct.toFloat() }
                if (v.size > 60) v.filterIndexed { idx, _ -> idx % (v.size / 60 + 1) == 0 } else v
            } catch (e: Exception) {
                emptyList()
            }
        }
        return sparkVals
    }

    fun graphic(c: Context, i: BatteryInfo, metric: String): RemoteViews {
        val rv = RemoteViews(c.packageName, R.layout.notif_graphic)
        val p = pal(c, i)
        val s = scale(c)
        val pad = Prefs.i(c, "n_pad_b", 12)
        rv.setViewPadding(R.id.g_content, dp(c, 14f), dp(c, pad.toFloat()), dp(c, 14f), dp(c, pad.toFloat()))
        rv.setImageViewBitmap(R.id.g_bg, bgBmp(c, p, 2f * pad + 84f))
        rv.setImageViewBitmap(R.id.g_ring, Gfx.ring(240, i.percent, p.bar, p.track))

        rv.setTextViewText(R.id.g_percent, "${i.percent}٪".fa())
        rv.setTextColor(R.id.g_percent, p.text)
        rv.setTextViewTextSize(R.id.g_percent, TypedValue.COMPLEX_UNIT_SP, 16f * s)
        rv.setTextViewText(R.id.g_status, statusText(i))
        rv.setTextColor(R.id.g_status, p.accent)
        rv.setTextViewTextSize(R.id.g_status, TypedValue.COMPLEX_UNIT_SP, 12f * s)
        rv.setTextViewText(R.id.g_main, Fmt.long(i, metric).fa())
        rv.setTextColor(R.id.g_main, p.text)
        rv.setTextViewTextSize(R.id.g_main, TypedValue.COMPLEX_UNIT_SP, 22f * s)

        val bmp = if (Prefs.b(c, "hist_on", true)) Gfx.spark(480, 64, sparkData(c, i.plugged), p.accent) else null
        rv.setViewVisibility(R.id.g_spark, if (bmp != null) View.VISIBLE else View.GONE)
        if (bmp != null) rv.setImageViewBitmap(R.id.g_spark, bmp)

        val parts = mutableListOf<String>()
        if (Prefs.b(c, "n_voltage", true)) parts.add(Fmt.long(i, "voltage"))
        if (Prefs.b(c, "n_power", true)) parts.add(Fmt.long(i, "power"))
        if (Prefs.b(c, "n_temp", true)) parts.add(Fmt.long(i, "temp"))
        if (Prefs.b(c, "n_time", true)) etaText(i)?.let { parts.add(it) }
        rv.setTextViewText(R.id.g_line, parts.joinToString("  •  ").fa())
        rv.setTextColor(R.id.g_line, p.muted)
        rv.setTextViewTextSize(R.id.g_line, TypedValue.COMPLEX_UNIT_SP, 11f * s)
        rv.setViewVisibility(R.id.g_line, if (parts.isEmpty()) View.GONE else View.VISIBLE)
        return rv
    }

    /** قالب ساده‌ی خود سیستم؛ هیچ‌وقت بریده نمیشه */
    fun applySystem(c: Context, b: NotificationCompat.Builder, i: BatteryInfo, metric: String) {
        val p = pal(c, i)
        val lines = mutableListOf<String>()
        lines.add(statusText(i))
        val row = mutableListOf<String>()
        if (Prefs.b(c, "n_voltage", true)) row.add("ولتاژ " + Fmt.long(i, "voltage"))
        if (Prefs.b(c, "n_power", true)) row.add("توان " + Fmt.long(i, "power"))
        if (Prefs.b(c, "n_temp", true)) row.add("دما " + Fmt.long(i, "temp"))
        if (row.isNotEmpty()) lines.add(row.joinToString("  •  "))
        if (Prefs.b(c, "n_time", true)) etaText(i)?.let { lines.add(it) }
        if (Prefs.b(c, "n_health", true)) lines.add("سلامت: " + i.health)
        b.setContentTitle("${Fmt.long(i, metric)} • ${i.percent}٪".fa())
            .setContentText(lines.getOrElse(1) { lines[0] }.fa())
            .setStyle(NotificationCompat.BigTextStyle().bigText(lines.joinToString("\n").fa()))
            .setProgress(100, i.percent, false)
            .setColor(if (p.accent == Color.WHITE) Themes.chargeInt(c) else p.accent)
    }

    /** قالب انتخابی رو روی Builder اعمال می‌کنه */
    fun applyTo(c: Context, b: NotificationCompat.Builder, i: BatteryInfo, metric: String) {
        val tpl = Prefs.s(c, "n_template", "card")
        val compat = Prefs.b(c, "n_compat", defaultCompat())
        when (tpl) {
            "system" -> applySystem(c, b, i, metric)
            "compact" -> {
                val v = compact(c, i, metric)
                b.setStyle(NotificationCompat.DecoratedCustomViewStyle()).setCustomContentView(v).setCustomBigContentView(v)
            }
            "graphic" -> {
                b.setStyle(NotificationCompat.DecoratedCustomViewStyle())
                    .setCustomContentView(compact(c, i, metric))
                    .setCustomBigContentView(if (compat) compact(c, i, metric) else graphic(c, i, metric))
            }
            else -> {
                b.setStyle(NotificationCompat.DecoratedCustomViewStyle())
                    .setCustomContentView(compact(c, i, metric))
                    .setCustomBigContentView(if (compat) compact(c, i, metric) else card(c, i, metric))
            }
        }
    }
}
