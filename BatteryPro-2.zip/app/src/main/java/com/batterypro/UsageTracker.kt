package com.batterypro

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object UsageTracker {
    data class AppUse(val pkg: String, val label: String, val minutes: Int, val system: Boolean)

    fun hasAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun info(c: Context, pkg: String): Pair<String, Boolean>? = try {
        val ai = c.packageManager.getApplicationInfo(pkg, 0)
        c.packageManager.getApplicationLabel(ai).toString() to ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
    } catch (e: Exception) {
        null
    }

    private fun dayStart(offset: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.DAY_OF_YEAR, offset)
        return cal.timeInMillis
    }

    private fun dayKey(offset: Int): String =
        SimpleDateFormat("yyyyMMdd", Locale.US).format(dayStart(offset))

    fun query(c: Context, from: Long, to: Long): List<AppUse> {
        if (!hasAccess(c)) return emptyList()
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        return usm.queryAndAggregateUsageStats(from, to).values.mapNotNull { u ->
            val min = (u.totalTimeInForeground / 60000).toInt()
            if (min < 1) null else info(c, u.packageName)?.let { AppUse(u.packageName, it.first, min, it.second) }
        }.sortedByDescending { it.minutes }
    }

    /** offset: 0 = امروز، -1 = دیروز، ... */
    fun day(c: Context, offset: Int): List<AppUse> {
        if (offset < 0) {
            val saved = load(c, dayKey(offset))
            if (saved.isNotEmpty()) return saved
        }
        val from = dayStart(offset)
        val to = if (offset == 0) System.currentTimeMillis() else dayStart(offset + 1)
        return query(c, from, to)
    }

    fun saveToday(c: Context) {
        val list = query(c, dayStart(0), System.currentTimeMillis())
        if (list.isEmpty()) return
        val sp = c.getSharedPreferences("usage_hist", Context.MODE_PRIVATE)
        val cutoff = dayKey(-30)
        val ed = sp.edit()
        sp.all.keys.filter { it < cutoff }.forEach { ed.remove(it) }
        ed.putString(dayKey(0), list.joinToString(";") { "${it.pkg}|${it.minutes}|${if (it.system) 1 else 0}" })
        ed.apply()
    }

    private fun load(c: Context, key: String): List<AppUse> {
        val s = c.getSharedPreferences("usage_hist", Context.MODE_PRIVATE).getString(key, null) ?: return emptyList()
        return s.split(";").mapNotNull { e ->
            val p = e.split("|")
            if (p.size < 3) null else AppUse(p[0], info(c, p[0])?.first ?: p[0], p[1].toIntOrNull() ?: 0, p[2] == "1")
        }
    }

    fun alertCheck(c: Context) {
        val limit = Prefs.i(c, "usage_min", 120)
        val sp = c.getSharedPreferences("usage_alerted", Context.MODE_PRIVATE)
        val key = dayKey(0)
        val done = (sp.getStringSet(key, emptySet()) ?: emptySet()).toMutableSet()
        for (a in query(c, dayStart(0), System.currentTimeMillis())) {
            if (a.minutes < limit || a.pkg in done) continue
            if (a.pkg == c.packageName || a.pkg.contains("launcher") || a.pkg.contains("systemui")) continue
            done.add(a.pkg)
            Notif.alert(
                c, 1000 + (a.pkg.hashCode() and 0xFFFF),
                "⚠️ مصرف بالا: ${a.label}",
                "امروز ${Fmt.dur(a.minutes)} استفاده شده".fa()
            )
        }
        sp.edit().clear().putStringSet(key, done).apply()
    }
}
