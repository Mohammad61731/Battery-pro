package com.batterypro

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        finish(c)
    }

    companion object {
        private fun pending(c: Context): PendingIntent = PendingIntent.getBroadcast(
            c, 77, Intent(c, TimerReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun schedule(c: Context, at: Long) {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(c))
        }

        fun cancel(c: Context) {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pending(c))
        }

        /** فقط یک بار اعلان میده، حتی اگه آلارم و سرویس همزمان برسن */
        fun finish(c: Context): Boolean {
            val te = Prefs.l(c, "tool_timer_end", 0L)
            if (te <= 0L) return false
            Prefs.putL(c, "tool_timer_end", 0L)
            Notif.alert(c, 20, "⏰ تایمر تمام شد", "زمانی که تنظیم کرده بودی تموم شد.")
            return true
        }
    }
}
