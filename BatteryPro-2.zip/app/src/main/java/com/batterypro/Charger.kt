package com.batterypro

import android.content.Context
import java.io.File
import java.util.Locale
import kotlin.math.sqrt

/** اندازه‌گیری مستقیم از سیستم (فقط اگه گوشی اجازه بده؛ بیشتر گوشی‌ها نمیدن) */
data class Direct(
    val vbusMv: Int,        // ولتاژ ورودی شارژر (۰ = نامشخص)
    val protocol: String,   // مثل USB_PD / USB_HVDCP / USB_DCP (خالی = نامشخص)
    val chargeType: String  // مثل Fast / Standard / Trickle (خالی = نامشخص)
)

object Sysfs {
    private fun read(path: String): String? = try {
        val f = File(path)
        if (f.exists() && f.canRead()) f.readText().trim() else null
    } catch (e: Exception) {
        null
    }

    private fun readMv(path: String): Int {
        val v = read(path)?.toLongOrNull() ?: return 0
        val mv = when {
            v > 100000L -> v / 1000L      // µV
            v > 100L -> v                 // mV
            else -> 0L
        }
        return if (mv in 3000L..22000L) mv.toInt() else 0
    }

    fun direct(plugged: Boolean): Direct {
        if (!plugged) return Direct(0, "", "")
        val base = "/sys/class/power_supply/"
        var v = 0
        for (p in listOf("usb/voltage_now", "ac/voltage_now", "wireless/voltage_now", "usb/input_voltage_now")) {
            v = readMv(base + p)
            if (v > 0) break
        }
        var proto = ""
        for (p in listOf("usb/real_type", "usb/usb_type", "usb/type")) {
            val t = read(base + p)
            if (!t.isNullOrEmpty() && !t.equals("Unknown", true) && !t.equals("USB", true) && t.length < 40) {
                proto = t
                break
            }
        }
        val ct = read(base + "battery/charge_type") ?: ""
        return Direct(v, proto, if (ct.equals("Unknown", true) || ct.equals("N/A", true)) "" else ct)
    }
}

data class Report(
    val avgW: Float,
    val peakW: Float,
    val avgMa: Int,
    val avgMv: Int,
    val maxMv: Int,
    val tempStart: Float,
    val tempEnd: Float,
    val stability: Int,        // ۰ تا ۱۰۰
    val dips: Int,
    val tier: String,          // slow / basic / normal / fast / turbo / hyper
    val tierLabel: String,
    val voltClass: String,     // رده‌ی ولتاژ (اندازه‌گیری یا تخمین)
    val voltMeasured: Boolean,
    val factoryRatio: Int,     // نسبت به شارژر فابریک (درصد)
    val level: Int,            // ۰ سالم، ۱ هشدار، ۲ خطرناک
    val score: Int,
    val verdict: String,       // یک خط
    val lines: List<String>,
    val samples: Int
) {
    fun watt(): String = String.format(Locale.US, "%.1f", avgW)
}

object ChargerAnalyzer {
    private fun trim(s: List<Sample>): List<Sample> {
        if (s.size < 4) return s
        val span = s.last().t - s.first().t
        // اگه نمونه‌ها کافی‌ان، ۶ ثانیه‌ی اول (ناپایدار) دور ریخته میشه
        if (span < 14000L) return s
        val from = s.first().t + 6000L
        val r = s.filter { it.t >= from }
        return if (r.size >= 3) r else s
    }

    fun tierOf(w: Float): Pair<String, String> = when {
        w < 3.5f -> "slow" to "خیلی کند"
        w < 7.5f -> "basic" to "کند (۵ وات)"
        w < 12f -> "normal" to "معمولی (۱۰ وات)"
        w < 20f -> "fast" to "سریع"
        w < 35f -> "turbo" to "خیلی سریع"
        else -> "hyper" to "فوق‌سریع"
    }

    /** رده‌ی ولتاژ شارژر؛ اگه اندازه‌گیری مستقیم نباشه از توان تخمین میزنه */
    fun voltClass(w: Float, d: Direct, maxMv: Int): Pair<String, Boolean> {
        if (maxMv > 3000) {
            return String.format(Locale.US, "تا %.0f ولت (اعلام‌شده توسط شارژر)", maxMv / 1000f) to true
        }
        if (d.vbusMv > 0) {
            val v = d.vbusMv / 1000f
            val txt = when {
                v < 4.5f -> String.format(Locale.US, "%.1f ولت — پایین‌تر از ۵ ولت (افت ولتاژ)", v)
                v <= 5.4f -> String.format(Locale.US, "%.1f ولت (۵ ولت استاندارد)", v)
                v in 8.0f..10.2f -> String.format(Locale.US, "%.1f ولت (۹ ولت؛ شارژ سریع)", v)
                v in 11.0f..13.2f -> String.format(Locale.US, "%.1f ولت (۱۲ ولت؛ شارژ سریع)", v)
                v in 14.0f..16.0f -> String.format(Locale.US, "%.1f ولت (۱۵ ولت؛ PD)", v)
                v in 19.0f..21.5f -> String.format(Locale.US, "%.1f ولت (۲۰ ولت؛ PD)", v)
                else -> String.format(Locale.US, "%.1f ولت (متغیر/PPS یا اختصاصی)", v)
            }
            return txt to true
        }
        val est = when {
            w <= 8f -> "احتمالاً ۵ ولت"
            w <= 14.5f -> "۵ ولت با جریان بالا یا ۹ ولت"
            w <= 30f -> "حتماً بالای ۵ ولت (احتمالاً ۹ تا ۱۲ ولت)"
            else -> "ولتاژ بالا (۱۱ تا ۲۰ ولت) یا پروتکل اختصاصی"
        }
        return "$est (تخمین)" to false
    }

    private fun std(v: List<Double>): Double {
        if (v.size < 2) return 0.0
        val m = v.average()
        return sqrt(v.map { (it - m) * (it - m) }.average())
    }

    /** تحلیل کامل. null یعنی نمونه‌ی کافی نیست. */
    fun analyze(raw: List<Sample>, i: BatteryInfo, factoryW: Int): Report? {
        val s = trim(raw)
        if (s.size < 3) return null
        val d = Sysfs.direct(i.plugged)

        val ma = s.map { it.ma.toDouble() }
        val mv = s.map { it.mv.toDouble() }
        val avgMa = ma.average()
        val avgMv = mv.average()
        val w = s.map { it.mv / 1000.0 * it.ma / 1000.0 }
        val avgW = w.average().toFloat()
        val peakW = (w.maxOrNull() ?: 0.0).toFloat()
        val maxMv = s.maxOf { it.mv }
        val cv = if (avgMa > 1) std(ma) / avgMa else 0.0
        val stability = (100 - (cv * 200).coerceAtMost(100.0)).toInt().coerceIn(0, 100)
        val med = ma.sorted()[ma.size / 2]
        val dips = if (med > 100) ma.count { it < med * 0.5 } else 0
        val ripple = std(mv)
        val tStart = s.first().tempC
        val tEnd = s.last().tempC
        val rise = tEnd - tStart

        val (tier, tierLabel) = tierOf(avgW)
        val (vc, measured) = voltClass(avgW, d, i.maxChgMv)
        val fw = factoryW.coerceAtLeast(5)
        val ratio = (avgW / (fw * 0.9f) * 100f).toInt()

        var level = 0
        var score = 100
        val lines = mutableListOf<String>()
        fun warn(msg: String, pen: Int, lv: Int) {
            lines.add(msg)
            score -= pen
            if (lv > level) level = lv
        }

        // ۱) ایمنی ولتاژ باتری
        if (i.health.contains("ولتاژ بالا") || maxMv > 4550) {
            warn("⛔ ولتاژ باتری از حد مجاز بالاتره (${String.format(Locale.US, "%.2f", maxMv / 1000f)} V). شارژر نامطمئن یا خرابه؛ فوراً جداش کن.", 60, 2)
        } else if (maxMv > 4480) {
            warn("⚠️ ولتاژ باتری بالای حد معمول (${String.format(Locale.US, "%.2f", maxMv / 1000f)} V) رسیده؛ اگه باتری هنوز زیر ۹۰٪ بود شارژر رو عوض کن.", 25, 1)
        }
        if (ripple > 70 && s.size >= 8) {
            warn("⚠️ ولتاژ شارژ نوسان زیادی داره (≈ ${ripple.toInt()} mV)؛ نشونه‌ی شارژر یا کابل بی‌کیفیته.", 20, 1)
        }

        // ۲) دما
        if (i.health.contains("داغ") || tEnd >= 45f) {
            warn("⛔ دمای باتری خیلی بالاست (${String.format(Locale.US, "%.1f", tEnd)}°C). شارژ رو قطع کن و بذار خنک بشه.", 40, 2)
        } else if (rise >= 5f || tEnd >= 41f) {
            warn("⚠️ باتری سریع گرم میشه (${String.format(Locale.US, "%+.1f", rise)}°C تو مدت تست). کاور رو دربیار و از گوشی کم‌تر استفاده کن.", 20, 1)
        }

        // ۳) پایداری جریان
        if (stability < 55 || dips >= 3) {
            warn("⚠️ جریان ناپایداره و چند بار قطع‌ووصل شده (${dips} افت). کابل یا درگاه شارژ (یا خود شارژر) مشکل داره.", 20, 1)
        }

        // ۴) سرعت نسبت به فابریک
        val verdict: String
        when {
            ratio >= 85 && ratio <= 125 -> {
                verdict = "هم‌سطح شارژر فابریکه ✅"
                lines.add("✅ سرعت شارژ با شارژر استاندارد گوشی (${fw}W) هم‌خوانی داره.")
            }
            ratio > 125 -> {
                verdict = "قوی‌تر از حد فابریک"
                lines.add("ℹ️ سرعت اندازه‌گیری‌شده از حد فابریکی که وارد کردی (${fw}W) بیشتره؛ یا عدد فابریک رو کمتر وارد کردی یا گوشی پروتکل سریع‌تری رو پشتیبانی می‌کنه. اگه شارژر مطمئن و استاندارده مشکلی نیست؛ گوشی خودش جریان رو محدود می‌کنه.")
            }
            ratio >= 55 -> {
                verdict = "کمی کندتر از فابریک"
                lines.add("ℹ️ ≈ ${ratio}٪ سرعت فابریک. اگه باتری بالای ۸۰٪ یا گوشی گرم یا در حال مصرف بود طبیعیه؛ وگرنه کابل/آداپتور رو امتحان کن.")
            }
            else -> {
                verdict = "خیلی کندتر از فابریک"
                if (i.plugType == 2) {
                    lines.add("ℹ️ گوشی شارژر رو «USB» شناخته (مثل پورت کامپیوتر یا شارژر ضعیف)؛ سرعت محدوده. با آداپتور دیواری تست کن.")
                } else {
                    lines.add("ℹ️ فقط ≈ ${ratio}٪ سرعت فابریک. شارژر/کابل ضعیفه یا گوشی به‌خاطر دما یا درصد بالا شارژ رو محدود کرده.")
                }
                if (level == 0) level = 1
                score -= 10
            }
        }
        if (i.percent >= 85) {
            lines.add("ℹ️ باتری بالای ۸۵٪ بود؛ تو این محدوده شارژ خودکار کند میشه و نتیجه‌ی تست دقیق نیست. برای تست دقیق بین ۱۰ تا ۷۰٪ امتحان کن.")
            score -= 5
        }
        if (measured && d.vbusMv > 0) {
            val v = d.vbusMv / 1000f
            if (v < 4.5f) warn("⚠️ ولتاژ ورودی شارژر پایین‌تر از ۵ ولته (${String.format(Locale.US, "%.1f", v)} V)؛ کابل بلند/نازک یا شارژر ضعیف.", 15, 1)
            else if (v > 5.4f && v !in 8.0f..10.2f && v !in 11.0f..13.2f && v !in 14.0f..16.0f && v !in 19.0f..21.5f && d.protocol.isEmpty())
                warn("⚠️ ولتاژ ورودی غیراستانداردی (${String.format(Locale.US, "%.1f", v)} V) دیده شد.", 10, 1)
        }
        if (d.protocol.isNotEmpty()) lines.add("🔌 پروتکل شناسایی‌شده: ${d.protocol}")
        if (d.chargeType.isNotEmpty()) lines.add("🔋 نوع شارژ از دید سیستم: ${d.chargeType}")
        if (!measured) lines.add("ℹ️ ولتاژ ورودی شارژر روی این گوشی قابل خوندن نیست؛ رده‌ی ولتاژ از روی توان تخمین زده شده.")

        if (level == 0) lines.add(0, "✅ رفتار شارژر عادیه؛ مورد خطرناکی دیده نشد.")
        return Report(
            avgW, peakW, avgMa.toInt(), avgMv.toInt(), maxMv, tStart, tEnd, stability, dips,
            tier, tierLabel, vc, measured, ratio, level, score.coerceIn(0, 100), verdict, lines, s.size
        )
    }

    fun levelText(l: Int) = when (l) {
        0 -> "سالم و استاندارد"
        1 -> "نیاز به دقت"
        else -> "خطرناک"
    }
}

/** ذخیره‌ی نتیجه‌ی تست شارژرها برای مقایسه */
object ChargerStore {
    data class Row(val t: Long, val name: String, val avgW: Float, val peakW: Float, val avgMv: Int, val rise: Float, val stab: Int, val score: Int, val level: Int, val tier: String)

    private const val KEY = "charger_tests"

    fun all(c: Context): List<Row> {
        val raw = Prefs.s(c, KEY, "")
        if (raw.isEmpty()) return emptyList()
        return raw.split("\n").mapNotNull { l ->
            val p = l.split("|")
            if (p.size < 10) null else try {
                Row(p[0].toLong(), p[1], p[2].toFloat(), p[3].toFloat(), p[4].toInt(), p[5].toFloat(), p[6].toInt(), p[7].toInt(), p[8].toInt(), p[9])
            } catch (e: Exception) {
                null
            }
        }
    }

    fun add(c: Context, name: String, r: Report) {
        val clean = name.replace("|", " ").replace("\n", " ").trim().ifEmpty { "شارژر بدون نام" }
        val line = listOf(
            System.currentTimeMillis(), clean, String.format(Locale.US, "%.1f", r.avgW), String.format(Locale.US, "%.1f", r.peakW),
            r.avgMv, String.format(Locale.US, "%.1f", r.tempEnd - r.tempStart), r.stability, r.score, r.level, r.tier
        ).joinToString("|")
        val rows = Prefs.s(c, KEY, "").split("\n").filter { it.isNotBlank() }.toMutableList()
        rows.add(0, line)
        Prefs.putS(c, KEY, rows.take(20).joinToString("\n"))
    }

    fun clear(c: Context) = Prefs.putS(c, KEY, "")
}

fun plugName(t: Int): String = when {
    t and 4 != 0 -> "شارژ بی‌سیم"
    t and 8 != 0 -> "داک"
    t and 2 != 0 -> "USB (پورت/شارژر کم‌توان)"
    t and 1 != 0 -> "آداپتور دیواری (AC)"
    else -> "نامشخص"
}

