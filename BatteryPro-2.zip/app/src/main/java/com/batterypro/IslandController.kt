package com.batterypro

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView

/** جزیره‌ی داینامیک: یه قرص مشکی بالای صفحه که با انیمیشن باز و بسته میشه */
class IslandController(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null
    private var tvIcon: TextView? = null
    private var tvTitle: TextView? = null
    private var tvSub: TextView? = null
    private var pulse: ObjectAnimator? = null

    var isPersistent = false
        private set

    private val dismissRun = Runnable { hide(true) }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    private fun canDraw() = Settings.canDrawOverlays(ctx)

    /** true یعنی تازه ساخته شد */
    private fun setup(color: Int): Boolean {
        val existing = root
        if (existing != null) {
            (existing.background as? GradientDrawable)?.setStroke(dp(1), color)
            return false
        }
        val ll = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(20), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(40).toFloat()
                setStroke(dp(1), color)
            }
            alpha = 0f
        }
        val icon = TextView(ctx).apply { textSize = 18f; setPadding(0, 0, dp(10), 0) }
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            maxWidth = dp(230); setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val sub = TextView(ctx).apply {
            setTextColor(Color.parseColor("#B0B7C3")); textSize = 11f
            maxWidth = dp(230); setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END
        }
        col.addView(title)
        col.addView(sub)
        ll.addView(icon)
        ll.addView(col)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(Prefs.i(ctx, "isl_y", 8))
        }
        try {
            wm.addView(ll, lp)
        } catch (e: Exception) {
            return false
        }
        root = ll; tvIcon = icon; tvTitle = title; tvSub = sub
        return true
    }

    private fun setTexts(icon: String, title: String, sub: String) {
        tvIcon?.text = icon
        tvTitle?.text = title
        tvSub?.text = sub
    }

    fun flash(icon: String, title: String, sub: String, color: Int) {
        if (isPersistent || !canDraw()) return
        h.removeCallbacks(dismissRun)
        val fresh = setup(color)
        val v = root ?: return
        setTexts(icon, title, sub)
        if (fresh) animIn(v)
        h.postDelayed(dismissRun, Prefs.i(ctx, "isl_sec", 4) * 1000L)
    }

    fun persistent(icon: String, title: String, sub: String, color: Int) {
        if (!canDraw()) return
        isPersistent = true
        h.removeCallbacks(dismissRun)
        val fresh = setup(color)
        val v = root ?: return
        setTexts(icon, title, sub)
        if (fresh) animIn(v)
    }

    fun remove() {
        h.removeCallbacks(dismissRun)
        hide(false)
    }

    private fun animIn(v: View) {
        val type = Prefs.s(ctx, "isl_anim", "spring")
        v.post {
            v.pivotX = v.width / 2f
            v.pivotY = 0f
            when (type) {
                "slide" -> {
                    v.translationY = -dp(90).toFloat()
                    v.animate().alpha(1f).translationY(0f).setDuration(380)
                        .setInterpolator(DecelerateInterpolator()).start()
                }
                "fade" -> v.animate().alpha(1f).setDuration(350).start()
                "stretch" -> {
                    v.scaleX = 0.15f; v.scaleY = 0.6f
                    v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520)
                        .setInterpolator(OvershootInterpolator(1.6f)).start()
                }
                else -> {
                    v.scaleX = 0.2f; v.scaleY = 0.2f
                    v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(450)
                        .setInterpolator(OvershootInterpolator(2f))
                        .withEndAction { if (type == "pulse") startPulse(v) }.start()
                }
            }
        }
    }

    private fun startPulse(v: View) {
        pulse = ObjectAnimator.ofPropertyValuesHolder(
            v,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.07f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.07f)
        ).apply {
            duration = 700
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun hide(animated: Boolean) {
        val v = root ?: return
        root = null
        isPersistent = false
        pulse?.cancel()
        pulse = null
        val kill = {
            try {
                wm.removeView(v)
            } catch (e: Exception) {
            }
        }
        if (!animated) {
            kill()
            return
        }
        val type = Prefs.s(ctx, "isl_anim", "spring")
        val a = v.animate().alpha(0f).setDuration(260)
        when (type) {
            "slide" -> a.translationY(-dp(90).toFloat())
            "fade" -> {}
            else -> a.scaleX(0.2f).scaleY(0.2f)
        }
        a.withEndAction { kill() }.start()
    }
}
