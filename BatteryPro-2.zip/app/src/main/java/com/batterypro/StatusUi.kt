package com.batterypro

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

// ───────────── اجزای گرافیکی ─────────────

@Composable
fun Spark(values: List<Float>, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val mn = values.minOrNull() ?: 0f
        val mx = values.maxOrNull() ?: 1f
        val rng = if (mx - mn > 0.0001f) mx - mn else 1f
        val line = Path()
        val fill = Path()
        values.forEachIndexed { idx, v ->
            val x = size.width * idx / (values.size - 1)
            val y = size.height * 0.1f + size.height * 0.8f * (1f - (v - mn) / rng)
            if (idx == 0) {
                line.moveTo(x, y)
                fill.moveTo(x, size.height)
                fill.lineTo(x, y)
            } else {
                line.lineTo(x, y)
                fill.lineTo(x, y)
            }
        }
        fill.lineTo(size.width, size.height)
        fill.close()
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(line, color, style = Stroke(width = 3.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** گیج کمانی با عدد وسط، توضیح وضعیت و نمودار مینی */
@Composable
fun GaugeCard(
    title: String, info: String, valueText: String, unit: String, caption: String,
    frac: Float, color: Color, spark: List<Float>, modifier: Modifier = Modifier
) {
    val anim by animateFloatAsState(targetValue = frac.coerceIn(0f, 1f), animationSpec = tween(700), label = "gauge")
    val track = Themes.cur.surfaceVar
    Card(
        modifier, shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontSize = 12.sp, color = Muted)
                InfoIcon(title, info)
            }
            Box(Modifier.fillMaxWidth().aspectRatio(1.2f), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().padding(6.dp)) {
                    val sw = size.minDimension * 0.12f
                    val d = size.minDimension - sw
                    val tl = Offset((size.width - d) / 2f, sw / 2f)
                    val sz = Size(d, d)
                    drawArc(track, 135f, 270f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                    if (anim > 0.005f) {
                        drawArc(color, 135f, 270f * anim, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(valueText, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(unit, fontSize = 11.sp, color = Muted)
                }
            }
            Text(caption, fontSize = 12.sp, color = color, fontWeight = FontWeight.Bold)
            Spark(spark, color, Modifier.fillMaxWidth().height(30.dp).padding(top = 4.dp))
        }
    }
}

/** حلقه‌ی بزرگ درصد باتری با درخشش وقتی شارژره */
@Composable
fun HeroRing(percent: Int, charging: Boolean, color: Color, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val anim by animateFloatAsState(targetValue = percent / 100f, animationSpec = tween(900), label = "ring")
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.15f, targetValue = 0.5f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "glow"
    )
    val track = Themes.cur.surfaceVar
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = size.minDimension * 0.085f
            val d = size.minDimension - sw * 2.4f
            val tl = Offset((size.width - d) / 2f, (size.height - d) / 2f)
            val sz = Size(d, d)
            if (charging) drawArc(color.copy(alpha = glow * 0.5f), -90f, 360f, false, tl, sz, style = Stroke(sw * 1.9f))
            drawArc(track, -90f, 360f, false, tl, sz, style = Stroke(sw))
            rotate(-90f) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(color.copy(alpha = 0.3f), color)),
                    startAngle = 0f, sweepAngle = 360f * anim, useCenter = false,
                    topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
        }
        content()
    }
}

// ───────────── صفحه‌ی وضعیت ─────────────

fun voltCaption(mv: Int): Pair<String, Color> = when {
    mv < 3400 -> "خیلی کم" to Red
    mv < 3600 -> "کم" to Orange
    mv <= 4460 -> "عادی" to Green
    else -> "خطرناک (بالا)" to Red
}

fun tempCaption(t: Float): Pair<String, Color> = when {
    t < 33f -> "خنک" to Blue
    t < 38f -> "عادی" to Green
    t < 42f -> "گرم" to Orange
    else -> "داغ" to Red
}

private fun pickScale(v: Float, scales: List<Float>): Float = scales.firstOrNull { it >= v } ?: scales.last()

@Composable
fun StatusScreen(onOpenCharger: () -> Unit) {
    val ctx = LocalContext.current
    var i by remember { mutableStateOf(BatteryReader.read(ctx)) }
    var tick by remember { mutableIntStateOf(0) }
    val hist = remember { mutableStateListOf<BatteryInfo>() }
    LaunchedEffect(Unit) {
        while (true) {
            i = BatteryReader.read(ctx)
            hist.add(i)
            if (hist.size > 45) hist.removeAt(0)
            tick++
            delay(1500)
        }
    }
    val nowMs = remember(tick) { System.currentTimeMillis() }
    val col = if (i.plugged) Green else Blue
    val surface = MaterialTheme.colorScheme.surface

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("باتری پرو", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        // ── قهرمان: حلقه‌ی درصد ──
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = surface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HeroRing(i.percent, i.plugged, col, Modifier.size(210.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            when {
                                i.plugged && i.full -> "✅ شارژ کامل"
                                i.plugged -> "⚡ در حال شارژ"
                                else -> "🔋 در حال مصرف"
                            }, color = col, fontWeight = FontWeight.Bold, fontSize = 13.sp
                        )
                        Text("${i.percent}٪".fa(), fontSize = 52.sp, fontWeight = FontWeight.Bold)
                        Text(plugLine(i), fontSize = 11.sp, color = Muted)
                    }
                }
                val t = if (i.plugged) "زمان تقریبی تا پر شدن" else "زمان تقریبی تا خالی شدن"
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when {
                            i.plugged && i.full -> "شارژ کامل ✅"
                            i.settling -> "در حال سنجش دقیق… (چند ثانیه‌ی اول اتصال)"
                            i.etaMin > 0 -> "$t ≈ ${Fmt.dur(i.etaMin)}".fa()
                            else -> "$t: در حال محاسبه…"
                        }, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = col
                    )
                    InfoIcon(t, Help.ETA)
                }
                if (i.tempC >= 38f && i.plugged) {
                    Text("🌡 دما بالاست؛ شارژ کندتر از حالت عادی پیش میره.", fontSize = 12.sp, color = Orange)
                }
            }
        }

        // ── گیج‌ها ──
        val curScale = pickScale(i.currentMa.toFloat(), listOf(1500f, 3000f, 6000f, 10000f))
        val wScale = pickScale(i.powerW, listOf(10f, 20f, 40f, 80f, 150f))
        val (vCap, vCol) = voltCaption(i.voltageMv)
        val (tCap, tCol) = tempCaption(i.tempC)
        val curCap = if (i.plugged) when {
            i.settling -> "در حال سنجش…"
            i.currentMa < 500 -> "کند"
            i.currentMa < 1500 -> "معمولی"
            i.currentMa < 3000 -> "سریع"
            else -> "خیلی سریع"
        } else when {
            i.currentMa < 300 -> "مصرف سبک"
            i.currentMa < 800 -> "مصرف متوسط"
            else -> "مصرف سنگین"
        }
        val wCap = if (i.plugged) {
            if (i.settling) "در حال سنجش…" else ChargerAnalyzer.tierOf(i.powerW).second
        } else if (i.powerW < 1f) "کم" else if (i.powerW < 3f) "متوسط" else "زیاد"

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GaugeCard(
                "ولتاژ", Help.VOLT, String.format(Locale.US, "%.2f", i.voltageMv / 1000f).fa(), "ولت (V)", vCap,
                (i.voltageMv - 3300f) / 1200f, vCol, hist.map { it.voltageMv.toFloat() }, Modifier.weight(1f)
            )
            GaugeCard(
                if (i.plugged) "جریان شارژ" else "جریان مصرف", Help.CURRENT, i.currentMa.toString().fa(), "میلی‌آمپر (mA)", curCap,
                i.currentMa / curScale, col, hist.map { it.currentMa.toFloat() }, Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GaugeCard(
                "توان", Help.POWER, String.format(Locale.US, "%.1f", i.powerW).fa(), "وات (W)", wCap,
                i.powerW / wScale, Orange, hist.map { it.powerW }, Modifier.weight(1f)
            )
            GaugeCard(
                "دما", Help.TEMP, String.format(Locale.US, "%.1f", i.tempC).fa(), "درجه (°C)", tCap,
                (i.tempC - 15f) / 45f, tCol, hist.map { it.tempC }, Modifier.weight(1f)
            )
        }

        // ── تحلیل زنده‌ی شارژر ──
        if (i.plugged) {
            val factory = Prefs.i(ctx, "factory_w", 25)
            val rep = remember(tick) { if (i.settling) null else ChargerAnalyzer.analyze(BatteryReader.chargeSamples(), i, factory) }
            val lc = if (rep == null) Muted else if (rep.level == 0) Green else if (rep.level == 1) Orange else Red
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("تحلیل شارژر (زنده)", color = Green, fontWeight = FontWeight.Bold)
                        InfoIcon("تحلیل شارژر", Help.CHG_LIVE)
                    }
                    if (rep == null) {
                        Text(
                            if (i.settling) "⏳ چند ثانیه‌ی اول بعد از وصل شارژر عددها ناپایداره؛ منتظر جا افتادن جریان و ولتاژ هستم تا نتیجه‌ی درست بدم."
                            else "نمونه‌ی کافی برای تحلیل هنوز جمع نشده…",
                            color = Muted, fontSize = 13.sp
                        )
                    } else {
                        Text("${rep.tierLabel} ≈ ${rep.watt()} وات".fa(), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = lc)
                        Text(rep.verdict + " • " + ChargerAnalyzer.levelText(rep.level), color = lc, fontSize = 13.sp)
                        Text("ولتاژ شارژر: " + rep.voltClass, fontSize = 12.sp, color = Muted)
                        rep.lines.take(2).forEach { Text(it.fa(), fontSize = 12.sp, color = Muted) }
                    }
                    OutlinedButton(onClick = onOpenCharger) { Text("تست دقیق شارژر ⚡") }
                }
            }
        }

        // ── سلامت و ظرفیت ──
        val design = Prefs.i(ctx, "design_mah", 0)
        val healthPct = if (i.sohPct > 0) i.sohPct else if (design > 0 && i.capacityMah > 0) (i.capacityMah * 100 / design).coerceAtMost(100) else -1
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("سلامت باتری", if (healthPct > 0) "$healthPct٪".fa() else i.health, Modifier.weight(1f), Help.HEALTH)
            StatCard("ظرفیت تخمینی", if (i.capacityMah > 0) "${i.capacityMah} mAh".fa() else "—", Modifier.weight(1f), Help.CAP)
        }
        if (i.cycles >= 0 || i.tech.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("تعداد سیکل", if (i.cycles >= 0) i.cycles.toString().fa() else "—", Modifier.weight(1f), Help.CYCLES)
                StatCard("نوع باتری", i.tech.ifEmpty { "—" }, Modifier.weight(1f), Help.TECH)
            }
        }
        if (healthPct <= 0 && design == 0) {
            Text("برای دیدن «سلامت تخمینی»، ظرفیت روی جعبه‌ی گوشی رو تو تب ⚡ شارژر وارد کن.", fontSize = 12.sp, color = Muted)
        }

        val ses = sessionText(ctx, i, nowMs)
        if (ses != null) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = surface)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(ses, Modifier.weight(1f))
                    InfoIcon("آمار نشست شارژ", Help.SESSION)
                }
            }
        }
        if (i.currentMa == 0) {
            Text("اگه جریان صفره، احتمالاً گوشیت این اطلاعات رو نمیده یا ثابت شده.", fontSize = 12.sp, color = Muted)
        }
        Spacer(Modifier.height(8.dp))
    }
}

fun plugLine(i: BatteryInfo): String = if (i.plugged) plugName(i.plugType) else "به شارژر وصل نیست"
