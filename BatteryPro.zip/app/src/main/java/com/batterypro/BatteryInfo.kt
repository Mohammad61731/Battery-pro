package com.batterypro

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

data class BatteryInfo(
    val percent: Int,
    val plugged: Boolean,
    val full: Boolean,
    val voltageMv: Int,
    val currentMa: Int,
    val tempC: Float,
    val health: String,
    val tech: String,
    val remainMin: Int
) {
    val powerW: Float get() = voltageMv / 1000f * currentMa / 1000f
}

fun String.fa(): String = map { if (it in '0'..'9') '\u06F0' + (it - '0') else it }.joinToString("")

object BatteryReader {
    fun read(c: Context): BatteryInfo {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (scale > 0) level * 100 / scale else level
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        var mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        if (mv in 1..99) mv *= 1000
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        // بعضی گوشی‌ها µA و بعضی mA برمی‌گردونن؛ تشخیص خودکار
        val ma = when {
            raw == Int.MIN_VALUE -> 0
            abs(raw) > 20000 -> abs(raw) / 1000
            else -> abs(raw)
        }
        val health = when (i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "سالم"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "داغ شده"
            BatteryManager.BATTERY_HEALTH_DEAD -> "خراب"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "ولتاژ بالا"
            BatteryManager.BATTERY_HEALTH_COLD -> "سرد"
            else -> "نامشخص"
        }
        var remain = -1
        if (plugged && Build.VERSION.SDK_INT >= 28) {
            val ms = bm.computeChargeTimeRemaining()
            if (ms > 0) remain = (ms / 60000).toInt()
        }
        return BatteryInfo(
            pct, plugged, status == BatteryManager.BATTERY_STATUS_FULL, mv, ma, temp,
            health, i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "", remain
        )
    }
}

object Fmt {
    val metrics = listOf(
        "current" to "جریان (mA)", "voltage" to "ولتاژ (V)", "power" to "توان (W)",
        "temp" to "دما (°C)", "percent" to "درصد باتری"
    )

    fun short(i: BatteryInfo, m: String): String = when (m) {
        "current" -> i.currentMa.toString()
        "voltage" -> String.format(Locale.US, "%.2f", i.voltageMv / 1000f)
        "power" -> String.format(Locale.US, "%.1f", i.powerW)
        "temp" -> "${i.tempC.roundToInt()}°"
        else -> i.percent.toString()
    }

    fun long(i: BatteryInfo, m: String): String = when (m) {
        "current" -> "${i.currentMa} mA"
        "voltage" -> String.format(Locale.US, "%.2f V", i.voltageMv / 1000f)
        "power" -> String.format(Locale.US, "%.1f W", i.powerW)
        "temp" -> String.format(Locale.US, "%.1f °C", i.tempC)
        else -> "${i.percent}٪"
    }

    fun dur(min: Int): String {
        val h = min / 60
        val m = min % 60
        return when {
            h > 0 && m > 0 -> "$h ساعت و $m دقیقه"
            h > 0 -> "$h ساعت"
            else -> "$m دقیقه"
        }
    }
}
