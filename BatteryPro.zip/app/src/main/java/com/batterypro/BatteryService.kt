package com.batterypro

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat
import java.util.Locale

class BatteryService : Service() {
    companion object {
        const val ID_LIVE = 1
        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, BatteryService::class.java))
        }
        fun stop(c: Context) {
            c.stopService(Intent(c, BatteryService::class.java))
        }
    }

    private val GREEN = Color.parseColor("#4ADE80")
    private val BLUE = Color.parseColor("#60A5FA")
    private val RED = Color.parseColor("#F87171")

    private val h = Handler(Looper.getMainLooper())
    private lateinit var nm: NotificationManager
    private lateinit var island: IslandController
    private var screenOn = true
    private var lastPlugged: Boolean? = null
    private var lastSig = ""
    private var nFull = false
    private var nHot = false
    private var nLimit = false
    private var lastHist = 0L
    private var lastUsage = 0L

    private val tick = object : Runnable {
        override fun run() {
            update()
            if (screenOn) h.postDelayed(this, Prefs.i(this@BatteryService, "interval", 3) * 1000L)
        }
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    screenOn = false
                    h.removeCallbacks(tick)
                }
                Intent.ACTION_SCREEN_ON -> {
                    screenOn = true
                    h.removeCallbacks(tick)
                    h.post(tick)
                }
                Intent.ACTION_BATTERY_CHANGED -> if (!screenOn) update()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        Notif.channels(this)
        island = IslandController(this)
        screenOn = getSystemService(PowerManager::class.java).isInteractive
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        ContextCompat.registerReceiver(this, rx, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val info = BatteryReader.read(this)
        val n = buildNotif(info)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_LIVE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_LIVE, n)
        }
        if (intent?.action == "TEST_ISLAND") {
            island.flash("⚡", "تست جزیره", "${Fmt.long(info, "current")} • ${info.percent}٪".fa(), GREEN)
        }
        h.removeCallbacks(tick)
        h.post(tick)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { unregisterReceiver(rx) } catch (e: Exception) { }
        island.remove()
        super.onDestroy()
    }

    private fun update() {
        val i = BatteryReader.read(this)
        val islOn = Prefs.b(this, "isl_on", false)

        // رویدادهای وصل/قطع شارژر
        val lp = lastPlugged
        if (lp != null && lp != i.plugged) {
            if (i.plugged) {
                nFull = false; nLimit = false
                if (islOn && Prefs.b(this, "isl_plug", true))
                    island.flash("⚡", "در حال شارژ", "${Fmt.long(i, "current")} • ${Fmt.long(i, "power")}".fa(), GREEN)
            } else if (islOn && Prefs.b(this, "isl_unplug", true)) {
                island.flash("🔌", "شارژر جدا شد", "${i.percent}٪".fa(), BLUE)
            }
        }
        lastPlugged = i.plugged

        // شارژ کامل
        if (i.plugged && (i.full || i.percent >= 100) && !nFull) {
            nFull = true
            if (Prefs.b(this, "alert_full", true)) Notif.alert(this, 10, "✅ شارژ کامل شد", "باتری ۱۰۰٪ است؛ شارژر رو جدا کن.")
            if (islOn && Prefs.b(this, "isl_full", true)) island.flash("✅", "شارژ کامل شد", "۱۰۰٪", GREEN)
        }
        // حد شارژ
        if (i.plugged && Prefs.b(this, "alert_limit", false)) {
            val lim = Prefs.i(this, "limit_pct", 80)
            if (i.percent >= lim && !nLimit) {
                nLimit = true
                Notif.alert(this, 12, "🔋 به حد شارژ رسید", "${i.percent}٪ شد؛ برای سلامت باتری شارژر رو جدا کن.".fa())
            }
        }
        // دمای بالا
        val hotC = Prefs.i(this, "hot_c", 42)
        if (i.tempC >= hotC) {
            if (!nHot) {
                nHot = true
                val t = String.format(Locale.US, "%.1f °C", i.tempC).fa()
                if (Prefs.b(this, "alert_hot", true)) Notif.alert(this, 11, "🔥 دمای باتری بالاست", t)
                if (islOn && Prefs.b(this, "isl_hot", true)) island.flash("🔥", "دمای بالا", t, RED)
            }
        } else if (i.tempC < hotC - 3) nHot = false

        // جزیره
        if (!islOn) island.remove()
        else if (Prefs.b(this, "isl_always", false)) {
            val key = if (i.plugged) "icon_charge" else "icon_discharge"
            island.persistent(
                if (i.plugged) "⚡" else "🔋",
                Fmt.long(i, Prefs.s(this, key, "current")).fa(),
                "${i.percent}٪ • ${Fmt.long(i, "temp")}".fa(),
                if (i.plugged) GREEN else BLUE
            )
        } else if (island.isPersistent) island.remove()

        // نوتیفیکیشن + آیکن نوار وضعیت + ویجت (فقط وقتی چیزی عوض شده)
        val sig = listOf(
            i.percent, i.plugged, i.currentMa, i.voltageMv, (i.tempC * 10).toInt(), i.remainMin, Prefs.hash(this)
        ).joinToString("|")
        if (sig != lastSig) {
            lastSig = sig
            nm.notify(ID_LIVE, buildNotif(i))
            BatteryWidget.refresh(this, i)
        }

        val now = System.currentTimeMillis()
        if (Prefs.b(this, "hist_on", true) && now - lastHist > 60_000) {
            lastHist = now
            HistoryStore.add(this, i)
        }
        if (now - lastUsage > 15 * 60_000L) {
            lastUsage = now
            Thread {
                try {
                    UsageTracker.saveToday(this)
                    if (Prefs.b(this, "alert_usage", false)) UsageTracker.alertCheck(this)
                } catch (e: Exception) { }
            }.start()
        }
    }

    private fun textIcon(text: String): IconCompat {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        var ts = 86f
        p.textSize = ts
        while (p.measureText(text) > size - 2 && ts > 20f) {
            ts -= 3f
            p.textSize = ts
        }
        val y = size / 2f - (p.descent() + p.ascent()) / 2f
        c.drawText(text, size / 2f, y, p)
        return IconCompat.createWithBitmap(bmp)
    }

    private fun buildNotif(i: BatteryInfo): Notification {
        val charging = i.plugged
        val key = if (charging) "icon_charge" else "icon_discharge"
        val metric = Prefs.s(this, key, "current")
        val b = NotificationCompat.Builder(this, Notif.CH_LIVE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(Notif.openApp(this))

        if (Prefs.b(this, "icon_on", true)) b.setSmallIcon(textIcon(Fmt.short(i, metric)))
        else b.setSmallIcon(R.drawable.ic_stat)

        val status = when {
            charging && i.full -> "✅ شارژ کامل"
            charging -> "⚡ در حال شارژ"
            else -> "🔋 در حال مصرف"
        }

        if (Prefs.b(this, "notif_on", true)) {
            val rv = RemoteViews(packageName, R.layout.notif_battery)
            rv.setInt(R.id.n_root, "setBackgroundResource", if (charging) R.drawable.bg_charge else R.drawable.bg_discharge)
            rv.setTextViewText(R.id.n_status, status)
            rv.setTextViewText(R.id.n_percent, "${i.percent}٪".fa())
            rv.setTextViewText(R.id.n_main, Fmt.long(i, metric).fa())
            rv.setProgressBar(R.id.n_bar, 100, i.percent, false)
            fun field(id: Int, prefKey: String, text: String) {
                rv.setTextViewText(id, text.fa())
                rv.setViewVisibility(id, if (Prefs.b(this, prefKey, true)) View.VISIBLE else View.GONE)
            }
            field(R.id.n_v, "n_voltage", "ولتاژ\n" + Fmt.long(i, "voltage"))
            field(R.id.n_p, "n_power", "توان\n" + Fmt.long(i, "power"))
            field(R.id.n_t, "n_temp", "دما\n" + Fmt.long(i, "temp"))
            field(
                R.id.n_r, "n_time",
                if (charging && i.remainMin > 0) "تا پر شدن\n" + Fmt.dur(i.remainMin) else "سلامت\n" + i.health
            )
            b.setStyle(NotificationCompat.DecoratedCustomViewStyle()).setCustomContentView(rv)
        } else {
            b.setContentTitle("${Fmt.long(i, metric)} • ${i.percent}٪".fa()).setContentText(status)
        }
        return b.build()
    }
}
