package com.batterypro

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

val Green = Color(0xFF4ADE80)
val Blue = Color(0xFF60A5FA)
val Orange = Color(0xFFFB923C)
val Muted = Color(0xFF9AA4B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notif.channels(this)
        if (Prefs.b(this, "svc_enabled", true)) BatteryService.start(this)
        setContent { App() }
    }
}

@Composable
fun App() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green, secondary = Blue,
            background = Color(0xFF0B0F14), surface = Color(0xFF151B23),
            onBackground = Color.White, onSurface = Color.White,
            surfaceVariant = Color(0xFF1E2630), onSurfaceVariant = Color(0xFFD1D5DB)
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            var tab by remember { mutableIntStateOf(0) }
            val tabs = listOf("وضعیت" to "🔋", "نمودار" to "📈", "برنامه‌ها" to "📱", "تنظیمات" to "⚙️")
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        tabs.forEachIndexed { idx, (t, e) ->
                            NavigationBarItem(
                                selected = tab == idx, onClick = { tab = idx },
                                icon = { Text(e, fontSize = 20.sp) }, label = { Text(t, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        0 -> StatusScreen()
                        1 -> ChartScreen()
                        2 -> AppsScreen()
                        else -> SettingsScreen()
                    }
                }
            }
        }
    }
}

// ───────────── کامپوننت‌های کمکی ─────────────

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontSize = 12.sp, color = Muted)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            content()
        }
    }
}

@Composable
fun SwitchRow(title: String, key: String, def: Boolean, sub: String? = null, onChange: (Boolean) -> Unit = {}) {
    val ctx = LocalContext.current
    var v by remember { mutableStateOf(Prefs.b(ctx, key, def)) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (sub != null) Text(sub, fontSize = 12.sp, color = Muted)
        }
        Switch(checked = v, onCheckedChange = { v = it; Prefs.putB(ctx, key, it); onChange(it) })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Chips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, l) ->
            FilterChip(selected = selected == k, onClick = { onSelect(k) }, label = { Text(l) })
        }
    }
}

@Composable
fun ChoiceRow(title: String, key: String, def: String, opts: List<Pair<String, String>>) {
    val ctx = LocalContext.current
    var v by remember { mutableStateOf(Prefs.s(ctx, key, def)) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title)
        Chips(opts, v) { v = it; Prefs.putS(ctx, key, it) }
    }
}

@Composable
fun StepRow(title: String, key: String, def: Int, min: Int, max: Int, step: Int, unit: String) {
    val ctx = LocalContext.current
    var v by remember { mutableIntStateOf(Prefs.i(ctx, key, def)) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        OutlinedButton(
            onClick = { v = (v - step).coerceAtLeast(min); Prefs.putI(ctx, key, v) },
            contentPadding = PaddingValues(0.dp), modifier = Modifier.size(36.dp)
        ) { Text("−") }
        Text("$v $unit".fa(), Modifier.padding(horizontal = 12.dp))
        OutlinedButton(
            onClick = { v = (v + step).coerceAtMost(max); Prefs.putI(ctx, key, v) },
            contentPadding = PaddingValues(0.dp), modifier = Modifier.size(36.dp)
        ) { Text("+") }
    }
}

@Composable
fun PermRow(title: String, ok: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        if (ok) Text("✅ فعال", color = Green) else Button(onClick = onClick) { Text("فعال‌سازی") }
    }
}

// ───────────── صفحه‌ی وضعیت ─────────────

@Composable
fun StatusScreen() {
    val ctx = LocalContext.current
    var i by remember { mutableStateOf(BatteryReader.read(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            i = BatteryReader.read(ctx)
            delay(1500)
        }
    }
    val col = if (i.plugged) Green else Blue
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("باتری پرو", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    when {
                        i.plugged && i.full -> "✅ شارژ کامل"
                        i.plugged -> "⚡ در حال شارژ"
                        else -> "🔋 در حال مصرف"
                    }, color = col, fontWeight = FontWeight.Bold
                )
                Text("${i.percent}٪".fa(), fontSize = 56.sp, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(
                    progress = { i.percent / 100f }, color = col,
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(6.dp))
                )
                if (i.plugged && i.remainMin > 0) Text("تا پر شدن: ${Fmt.dur(i.remainMin)}".fa(), color = Muted)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(if (i.plugged) "جریان شارژ" else "جریان مصرف", Fmt.long(i, "current").fa(), Modifier.weight(1f))
            StatCard("توان", Fmt.long(i, "power").fa(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("ولتاژ", Fmt.long(i, "voltage").fa(), Modifier.weight(1f))
            StatCard("دما", Fmt.long(i, "temp").fa(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("سلامت", i.health, Modifier.weight(1f))
            StatCard("نوع باتری", i.tech.ifEmpty { "—" }, Modifier.weight(1f))
        }
        if (i.currentMa == 0) {
            Text("اگه جریان صفره، احتمالاً گوشیت این اطلاعات رو نمیده یا ثابت شده.", fontSize = 12.sp, color = Muted)
        }
    }
}

// ───────────── نمودار ─────────────

@Composable
fun LineChart(values: List<Float>, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val mn = values.minOrNull() ?: 0f
        val mx = values.maxOrNull() ?: 1f
        val rng = if (mx - mn > 0f) mx - mn else 1f
        val path = Path()
        values.forEachIndexed { idx, v ->
            val x = size.width * idx / (values.size - 1)
            val y = size.height * 0.05f + size.height * 0.9f * (1f - (v - mn) / rng)
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color, style = Stroke(width = 5f))
    }
}

@Composable
fun ChartScreen() {
    val ctx = LocalContext.current
    var metric by remember { mutableStateOf("pct") }
    var hours by remember { mutableStateOf("6") }
    var pts by remember { mutableStateOf(emptyList<HistoryStore.P>()) }
    LaunchedEffect(hours) {
        while (true) {
            pts = withContext(Dispatchers.IO) { HistoryStore.read(ctx, hours.toInt()) }
            delay(30000)
        }
    }
    val vals = pts.map {
        when (metric) {
            "pct" -> it.pct.toFloat()
            "ma" -> it.ma.toFloat()
            "mv" -> it.mv / 1000f
            else -> it.temp
        }
    }
    val shown = if (vals.size > 240) vals.filterIndexed { idx, _ -> idx % (vals.size / 240 + 1) == 0 } else vals
    val (label, color) = when (metric) {
        "pct" -> "درصد باتری" to Green
        "ma" -> "جریان (mA)" to Blue
        "mv" -> "ولتاژ (V)" to Orange
        else -> "دما (°C)" to Color(0xFFF87171)
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("نمودار تاریخچه", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Chips(listOf("pct" to "درصد", "ma" to "جریان", "mv" to "ولتاژ", "temp" to "دما"), metric) { metric = it }
        Chips(listOf("1" to "۱ ساعت", "6" to "۶ ساعت", "24" to "۲۴ ساعت"), hours) { hours = it }
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(label, color = color, fontWeight = FontWeight.Bold)
                if (shown.size < 2) {
                    Text("هنوز داده‌ی کافی ثبت نشده؛ چند دقیقه برنامه رو باز بذار تا نمودار پر بشه.", color = Muted)
                } else {
                    LineChart(shown, color, Modifier.fillMaxWidth().height(220.dp))
                    val mn = shown.minOrNull() ?: 0f
                    val mx = shown.maxOrNull() ?: 0f
                    val avg = shown.average().toFloat()
                    Text(
                        String.format(java.util.Locale.US, "کمترین %.1f  •  بیشترین %.1f  •  میانگین %.1f", mn, mx, avg).fa(),
                        fontSize = 12.sp, color = Muted
                    )
                }
            }
        }
    }
}

// ───────────── برنامه‌ها ─────────────

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    var access by remember { mutableStateOf(UsageTracker.hasAccess(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            access = UsageTracker.hasAccess(ctx)
            delay(1000)
        }
    }
    var day by remember { mutableStateOf("0") }
    var filter by remember { mutableStateOf("all") }
    var list by remember { mutableStateOf(emptyList<UsageTracker.AppUse>()) }
    LaunchedEffect(day, access) {
        list = if (access) withContext(Dispatchers.IO) { UsageTracker.day(ctx, -day.toInt()) } else emptyList()
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("مصرف برنامه‌ها", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (!access) {
            Section("نیاز به دسترسی") {
                Text("برای دیدن زمان استفاده‌ی برنامه‌ها باید «دسترسی به داده‌های استفاده» رو فعال کنی.", color = Muted)
                Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) { Text("باز کردن تنظیمات") }
            }
        } else {
            Chips(
                listOf("0" to "امروز", "1" to "دیروز", "2" to "۲ روز پیش", "3" to "۳ روز پیش", "4" to "۴ روز پیش", "5" to "۵ روز پیش", "6" to "۶ روز پیش"),
                day
            ) { day = it }
            Chips(listOf("all" to "همه", "user" to "شخصی (نصب‌شده)", "sys" to "رسمی (سیستمی)"), filter) { filter = it }
            val shown = list.filter { filter == "all" || (filter == "sys") == it.system }
            val total = shown.sumOf { it.minutes }
            val maxMin = (shown.maxOfOrNull { it.minutes } ?: 1).coerceAtLeast(1)
            Text("مجموع: ${Fmt.dur(total)}".fa(), color = Muted)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown) { a ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row {
                                Text(a.label, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                                Text(Fmt.dur(a.minutes).fa(), color = if (a.minutes >= 120) Orange else Muted)
                            }
                            LinearProgressIndicator(
                                progress = { a.minutes / maxMin.toFloat() },
                                color = if (a.minutes >= 120) Orange else Green,
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}

// ───────────── تنظیمات ─────────────

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var notifOk by remember { mutableStateOf(true) }
    var overlayOk by remember { mutableStateOf(false) }
    var usageOk by remember { mutableStateOf(false) }
    var batOk by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            notifOk = Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            overlayOk = Settings.canDrawOverlays(ctx)
            usageOk = UsageTracker.hasAccess(ctx)
            batOk = ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
            delay(1000)
        }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val animOpts = listOf("spring" to "فنری", "stretch" to "کشسان", "slide" to "کشویی", "fade" to "محو", "pulse" to "ضربانی")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("تنظیمات", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Section("عمومی") {
            SwitchRow("فعال بودن برنامه", "svc_enabled", true, "اگه خاموش باشه هیچ‌چیز در پس‌زمینه اجرا نمیشه") {
                if (it) BatteryService.start(ctx) else BatteryService.stop(ctx)
            }
            StepRow("فاصله‌ی به‌روزرسانی (فقط وقتی صفحه روشنه)", "interval", 3, 1, 10, 1, "ثانیه")
            SwitchRow("ثبت تاریخچه برای نمودار", "hist_on", true)
        }

        Section("نوار وضعیت (عدد زنده کنار آیکن‌ها)") {
            Text(
                "اندروید اجازه نمیده متن دلخواه دقیقاً کنار ساعت نوشته بشه؛ به‌جاش عدد زنده داخل آیکن نوار وضعیت نشون داده میشه.",
                fontSize = 12.sp, color = Muted
            )
            SwitchRow("نمایش عدد به‌جای آیکن باتری", "icon_on", true)
            ChoiceRow("وقتی به شارژر وصله، نشون بده:", "icon_charge", "current", Fmt.metrics)
            ChoiceRow("وقتی به شارژر وصل نیست، نشون بده:", "icon_discharge", "current", Fmt.metrics)
        }

        Section("نوار اعلان (کارت گرافیکی)") {
            SwitchRow("نمایش کارت وضعیت", "notif_on", true)
            SwitchRow("ولتاژ", "n_voltage", true)
            SwitchRow("توان (وات)", "n_power", true)
            SwitchRow("دما", "n_temp", true)
            SwitchRow("زمان تا پر شدن / سلامت باتری", "n_time", true)
        }

        Section("جزیره‌ی داینامیک") {
            SwitchRow("فعال‌سازی جزیره", "isl_on", false, "نیاز به دسترسی «نمایش روی برنامه‌های دیگر»")
            PermRow("دسترسی نمایش روی برنامه‌های دیگر", overlayOk) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
            }
            ChoiceRow("نوع انیمیشن", "isl_anim", "spring", animOpts)
            SwitchRow("نمایش هنگام وصل شدن شارژر", "isl_plug", true)
            SwitchRow("نمایش هنگام جدا شدن شارژر", "isl_unplug", true)
            SwitchRow("نمایش هنگام شارژ کامل", "isl_full", true)
            SwitchRow("نمایش هنگام دمای بالا", "isl_hot", true)
            SwitchRow("همیشه نمایان باشه (نمایش زنده)", "isl_always", false, "اطلاعات زنده همیشه بالای صفحه می‌مونه")
            StepRow("مدت نمایش", "isl_sec", 4, 2, 15, 1, "ثانیه")
            StepRow("فاصله از بالای صفحه", "isl_y", 8, 0, 60, 2, "dp")
            Button(onClick = {
                ContextCompat.startForegroundService(ctx, Intent(ctx, BatteryService::class.java).setAction("TEST_ISLAND"))
            }) { Text("تست جزیره") }
        }

        Section("هشدارها") {
            SwitchRow("هشدار شارژ کامل", "alert_full", true)
            SwitchRow("هشدار دمای بالا", "alert_hot", true)
            StepRow("حد دمای هشدار", "hot_c", 42, 35, 55, 1, "درجه")
            SwitchRow("هشدار حد شارژ (برای سلامت باتری)", "alert_limit", false, "فقط هشدار میده؛ قطع شارژ بدون روت ممکن نیست")
            StepRow("حد شارژ", "limit_pct", 80, 50, 100, 5, "٪")
            SwitchRow("هشدار برنامه‌ی پرمصرف", "alert_usage", false, "نیاز به دسترسی داده‌های استفاده")
            StepRow("هشدار بعد از", "usage_min", 120, 15, 480, 15, "دقیقه")
        }

        Section("دسترسی‌ها") {
            PermRow("اعلان‌ها", notifOk) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            PermRow("داده‌های استفاده‌ی برنامه‌ها", usageOk) { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            PermRow("بدون محدودیت باتری (برای پایدار ماندن)", batOk) {
                ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
