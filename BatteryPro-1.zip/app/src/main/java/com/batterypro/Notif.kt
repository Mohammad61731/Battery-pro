package com.batterypro

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import androidx.core.app.NotificationCompat

object Notif {
    const val CH_LIVE = "live"

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_LIVE, "وضعیت زنده باتری", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
        )
        nm.createNotificationChannel(NotificationChannel("alert", "هشدار (با صدا)", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(
            NotificationChannel("alert_silent", "هشدار (بی‌صدا)", NotificationManager.IMPORTANCE_LOW).apply { setSound(null, null) }
        )
        nm.createNotificationChannel(
            NotificationChannel("alert_vibe", "هشدار (فقط ارتعاش)", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
            }
        )
    }

    private fun alertChannel(c: Context): String {
        return when (Prefs.s(c, "alert_mode", "sound")) {
            "silent" -> "alert_silent"
            "vibrate" -> "alert_vibe"
            "custom" -> customChannel(c)
            else -> "alert"
        }
    }

    private fun customChannel(c: Context): String {
        val uri = Prefs.s(c, "alert_uri", "")
        if (uri.isEmpty()) return "alert"
        val id = "alert_c_" + (uri.hashCode() and 0x7FFFFFFF)
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, "هشدار (صدای دلخواه)", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                Uri.parse(uri),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build()
            )
            nm.createNotificationChannel(ch)
        }
        return id
    }

    fun openApp(c: Context): PendingIntent = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun alert(c: Context, id: Int, title: String, text: String) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val n = NotificationCompat.Builder(c, alertChannel(c))
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openApp(c))
            .build()
        nm.notify(id, n)
    }
}
