package com.batterypro

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

data class BatteryInfo(
    val percent: Int,
    val plugged: Boolean,
    val full: Boolean,
    val voltageMv: Int,
    val currentMa: Int,
    val tempC: Float,
    val health: String,
    val tech: String,
    val remainMin: Int,
    val etaMin: Int,        // موقع شارژ: تا پر شدن، موقع مصرف: تا خالی شدن (-1 = نامشخص)
    val capacityMah: Int    // ظرفیت تخمینی (0 = نامشخص)
) {
    val powerW: Float get() = voltageMv / 1000f * currentMa / 1000f
}

fun String.fa(): String = map { if (it in '0'..'9') '\u06F0' + (it - '0') else it }.joinToString("")

object BatteryReader {
    private var ema = 0f
    fun resetEma() { ema = 0f }

    fun read(c: Context): BatteryInfo {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (scale > 0) level * 100 / scale else level
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        var mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        if (mv in 1..99) mv *= 1000
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val ma = when {
            raw == Int.MIN_VALUE -> 0
            abs(raw) > 20000 -> abs(raw) / 1000
            else -> abs(raw)
        }
        ema = if (ema <= 0f) ma.toFloat() else ema * 0.8f + ma * 0.2f

        val health = when (i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "سالم"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "داغ شده"
            BatteryManager.BATTERY_HEALTH_DEAD -> "خراب"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "ولتاژ بالا"
            BatteryManager.BATTERY_HEALTH_COLD -> "سرد"
            else -> "نامشخص"
        }
        var remain = -1
        if (plugged && Build.VERSION.SDK_INT >= 28) {
            val ms = bm.computeChargeTimeRemaining()
            if (ms > 0) remain = (ms / 60000).toInt()
        }
        // ظرفیت تخمینی = شمارنده‌ی شارژ ÷ درصد
        var cap = 0
        val cc = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        if (cc > 0L && pct >= 5) {
            val mah = if (cc > 20000L) cc / 1000.0 else cc.toDouble()
            val est = (mah * 100.0 / pct).toInt()
            if (est in 1500..20000) cap = est
        }
        var eta = if (plugged) Eta.charge(pct, cap, ema, temp) else Eta.discharge(pct, cap, ema)
        if (plugged && eta < 0 && remain > 0) eta = remain
        return BatteryInfo(
            pct, plugged, status == BatteryManager.BATTERY_STATUS_FULL, mv, ma, temp,
            health, i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "", remain, eta, cap
        )
    }
}

object Eta {
    /** مدل شارژ دومرحله‌ای: تا ۸۰٪ جریان ثابت، بعد از اون جریان کم میشه؛ دمای بالا هم سرعت رو پایین میاره */
    fun charge(pct: Int, cap: Int, curMa: Float, tempC: Float): Int {
        if (cap <= 0 || curMa < 100f || pct >= 100) return -1
        val derate = if (tempC > 38f) (1f - (tempC - 38f) * 0.04f).coerceAtLeast(0.5f) else 1f
        val i = curMa * derate
        val hours: Float = if (pct < 80) {
            cap * (80 - pct) / 100f / i + cap * 20f / 100f / (i * 0.4f)
        } else {
            cap * (100 - pct) / 100f / (i * 0.6f)
        }
        return (hours * 60f).toInt().coerceAtLeast(1)
    }

    fun discharge(pct: Int, cap: Int, curMa: Float): Int {
        if (cap <= 0 || curMa < 30f || pct <= 0) return -1
        return (cap * pct / 100f / curMa * 60f).toInt().coerceAtLeast(1)
    }
}

object Session {
    fun start(c: Context, pct: Int) {
        Prefs.putL(c, "sess_start_t", System.currentTimeMillis())
        Prefs.putI(c, "sess_start_pct", pct)
        Prefs.putL(c, "sess_end_t", 0L)
    }

    fun end(c: Context, pct: Int) {
        Prefs.putL(c, "sess_end_t", System.currentTimeMillis())
        Prefs.putI(c, "sess_end_pct", pct)
    }
}

object Fmt {
    val metrics = listOf(
        "current" to "جریان (mA)", "voltage" to "ولتاژ (V)", "power" to "توان (W)",
        "temp" to "دما (°C)", "percent" to "درصد باتری"
    )

    fun short(i: BatteryInfo, m: String): String = when (m) {
        "current" -> i.currentMa.toString()
        "voltage" -> String.format(Locale.US, "%.2f", i.voltageMv / 1000f)
        "power" -> String.format(Locale.US, "%.1f", i.powerW)
        "temp" -> "${i.tempC.roundToInt()}°"
        else -> i.percent.toString()
    }

    fun unit(m: String): String = when (m) {
        "current" -> "mA"
        "voltage" -> "V"
        "power" -> "W"
        "temp" -> "°C"
        else -> "%"
    }

    fun long(i: BatteryInfo, m: String): String = when (m) {
        "current" -> "${i.currentMa} mA"
        "voltage" -> String.format(Locale.US, "%.2f V", i.voltageMv / 1000f)
        "power" -> String.format(Locale.US, "%.1f W", i.powerW)
        "temp" -> String.format(Locale.US, "%.1f °C", i.tempC)
        else -> "${i.percent}٪"
    }

    fun dur(min: Int): String {
        val h = min / 60
        val m = min % 60
        return when {
            h > 0 && m > 0 -> "$h ساعت و $m دقیقه"
            h > 0 -> "$h ساعت"
            else -> "$m دقیقه"
        }
    }

    fun clock(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }
}
